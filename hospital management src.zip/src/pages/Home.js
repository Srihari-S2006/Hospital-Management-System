import React, { useEffect, useState } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  IconButton,
  Menu,
  MenuItem,
  Container,
  Grid,
  Card,
  CardMedia,
  CardContent,
  CardActions,
  Box,
  Paper,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Fab,
  useMediaQuery,
  useTheme,
  Hidden,
  Avatar,
  CardActionArea,
  Collapse,
  Link
} from '@mui/material';
import {
  Menu as MenuIcon,
  Search as SearchIcon,
  PlayArrow as PlayIcon,
  Apple as AppleIcon,
  Android as AndroidIcon,
  Facebook,
  Twitter,
  LinkedIn,
  WhatsApp,
  Place as PlaceIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  Fax as FaxIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon
} from '@mui/icons-material';
import { makeStyles } from '@mui/styles';
import { ThemeProvider, createTheme } from '@mui/material/styles';

// Custom theme
const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
  },
});

// Styles
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  title: {
    flexGrow: 1,
  },
  carouselItem: {
    height: 480,
  },
  carouselImg: {
    height: '100%',
    objectFit: 'cover',
  },
  cardImg: {
    height: 400,
    objectFit: 'cover',
  },
  statsBox: {
    background: `url('https://source.unsplash.com/1600x900/?medical,hospital') no-repeat center center/cover`,
    color: 'white',
    textAlign: 'center',
    padding: theme.spacing(5, 2.5),
    borderRadius: 10,
  },
  serviceCard: {
    background: 'white',
    padding: theme.spacing(2.5),
    borderRadius: 10,
    boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
    transition: 'transform 0.3s ease-in-out',
    '&:hover': {
      transform: 'translateY(-5px)',
    },
  },
  icon: {
    fontSize: 40,
    color: '#E63946',
  },
  centreItem: {
    textAlign: 'center',
    '& img': {
      width: 80,
      height: 80,
      border: '2px solid #007b8f',
      borderRadius: '50%',
      padding: 10,
    },
  },
  doctorCard: {
    backgroundColor: 'white',
    borderRadius: 15,
    padding: theme.spacing(2.5),
    textAlign: 'center',
    boxShadow: '0 5px 15px rgba(0, 0, 0, 0.1)',
    transition: 'transform 0.3s ease-in-out',
    '&:hover': {
      transform: 'translateY(-10px)',
    },
    '& img': {
      width: 120,
      height: 120,
      borderRadius: '50%',
      objectFit: 'cover',
      border: '5px solid #e0e0e0',
      backgroundColor: 'white',
    },
  },
  floatingIcon: {
    position: 'fixed',
    bottom: 20,
    right: 20,
    width: 50,
    height: 50,
    backgroundColor: '#007bff',
    borderRadius: '50%',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.3)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
  },
  customCard: {
    borderRadius: 10,
    overflow: 'hidden',
    transition: 'transform 0.3s',
    '&:hover': {
      transform: 'scale(1.05)',
    },
    '& img': {
      width: '100%',
      height: 200,
      objectFit: 'cover',
    },
  },
  counterBox: {
    fontSize: 40,
    fontWeight: 'bold',
  },
  footer: {
    backgroundColor: '#2C2F3F',
    color: 'white',
    padding: theme.spacing(5, 0),
  },
  footerLink: {
    color: 'white',
    textDecoration: 'none',
    '&:hover': {
      textDecoration: 'underline',
    },
  },
  emergencyLink: {
    color: 'red',
    fontWeight: 'bold',
  },
}));

// Navigation Component
const Navigation = () => {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = useState(null);
  const [appointmentAnchorEl, setAppointmentAnchorEl] = useState(null);
  const [hospitalAnchorEl, setHospitalAnchorEl] = useState(null);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleAppointmentMenuOpen = (event) => {
    setAppointmentAnchorEl(event.currentTarget);
  };

  const handleHospitalMenuOpen = (event) => {
    setHospitalAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setAppointmentAnchorEl(null);
    setHospitalAnchorEl(null);
  };

  return (
    <AppBar position="fixed">
      <Toolbar>
        <Typography variant="h6" className={classes.title}>
          Healing Hands
        </Typography>
        
        {isMobile ? (
          <>
            <IconButton
              edge="start"
              className={classes.menuButton}
              color="inherit"
              aria-label="menu"
              onClick={handleMenuOpen}
            >
              <MenuIcon />
            </IconButton>
            <Menu
              id="mobile-menu"
              anchorEl={anchorEl}
              keepMounted
              open={Boolean(anchorEl)}
              onClose={handleMenuClose}
            >
              <MenuItem onClick={handleMenuClose} component="a" href="index.html">Home</MenuItem>
              <MenuItem onClick={handleMenuClose} component="a" href="#ram">Our Specialties</MenuItem>
              
              <MenuItem onClick={handleAppointmentMenuOpen}>
                Appointment <ExpandMoreIcon />
              </MenuItem>
              <Collapse in={Boolean(appointmentAnchorEl)} timeout="auto" unmountOnExit>
                <List component="div" disablePadding>
                  <ListItem button component="a" href="appointmentForm.html">
                    <ListItemText primary="Book Appointment" />
                  </ListItem>
                  <ListItem button>
                    <ListItemText primary="View Appointment" />
                  </ListItem>
                  <ListItem button>
                    <ListItemText primary="Reschedule/Cancel" />
                  </ListItem>
                </List>
              </Collapse>
              
              <MenuItem onClick={handleHospitalMenuOpen}>
                Hospital <ExpandMoreIcon />
              </MenuItem>
              <Collapse in={Boolean(hospitalAnchorEl)} timeout="auto" unmountOnExit>
                <List component="div" disablePadding>
                  <ListItem button component="a" href="history.html">
                    <ListItemText primary="History" />
                  </ListItem>
                  <ListItem button component="a" href="about_us.html">
                    <ListItemText primary="About Us" />
                  </ListItem>
                  <ListItem button component="a" href="contactus.html">
                    <ListItemText primary="Contact Us" />
                  </ListItem>
                  <ListItem button component="a" href="FAQ.html">
                    <ListItemText primary="FAQs" />
                  </ListItem>
                </List>
              </Collapse>
            </Menu>
          </>
        ) : (
          <>
            <Button color="inherit" href="index.html">Home</Button>
            <Button color="inherit" href="#ram">Our Specialties</Button>
            
            <Button 
              color="inherit" 
              onClick={handleAppointmentMenuOpen}
              endIcon={<ExpandMoreIcon />}
            >
              Appointment
            </Button>
            <Menu
              id="appointment-menu"
              anchorEl={appointmentAnchorEl}
              keepMounted
              open={Boolean(appointmentAnchorEl)}
              onClose={handleMenuClose}
            >
              <MenuItem onClick={handleMenuClose} component="a" href="appointmentForm.html">Book Appointment</MenuItem>
              <MenuItem onClick={handleMenuClose}>View Appointment</MenuItem>
              <MenuItem onClick={handleMenuClose}>Reschedule/Cancel</MenuItem>
            </Menu>
            
            <Button 
              color="inherit" 
              onClick={handleHospitalMenuOpen}
              endIcon={<ExpandMoreIcon />}
            >
              Hospital
            </Button>
            <Menu
              id="hospital-menu"
              anchorEl={hospitalAnchorEl}
              keepMounted
              open={Boolean(hospitalAnchorEl)}
              onClose={handleMenuClose}
            >
              <MenuItem onClick={handleMenuClose} component="a" href="history.html">History</MenuItem>
              <MenuItem onClick={handleMenuClose} component="a" href="about_us.html">About Us</MenuItem>
              <MenuItem onClick={handleMenuClose} component="a" href="contactus.html">Contact Us</MenuItem>
              <MenuItem onClick={handleMenuClose} component="a" href="FAQ.html">FAQs</MenuItem>
            </Menu>
          </>
        )}
        
        <Box sx={{ display: 'flex', alignItems: 'center', ml: 2 }}>
          <SearchIcon sx={{ mr: 1 }} />
          <input 
            type="search" 
            placeholder="Search" 
            style={{ 
              padding: '5px', 
              borderRadius: '4px', 
              border: '1px solid #ccc',
              backgroundColor: 'transparent',
              color: 'white',
              '::placeholder': {
                color: 'white',
              }
            }} 
          />
        </Box>
      </Toolbar>
    </AppBar>
  );
};

// Hero Video Component
const HeroVideo = () => {
  return (
    <Box sx={{ width: '100%', mt: 8 }}>
      <video 
        autoPlay 
        muted 
        playsInline 
        loop 
        style={{ width: '100%' }}
        src="https://billrothhospitals.com/wp-content/uploads/2024/04/Adhitri_Master_1080P_1.mp4"
      />
    </Box>
  );
};

// Specialties Carousel Component
const SpecialtiesCarousel = () => {
  const classes = useStyles();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isTablet = useMediaQuery(theme.breakpoints.between('sm', 'md'));

  const specialties = [
    {
      title: "Nephrology",
      image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/nephrology.webp"
    },
    {
      title: "Occupational Medicine",
      image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/occupational_medicine.webp"
    },
    {
      title: "Ophthalmology",
      image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/ophthalmology.webp"
    },
    {
      title: "Pulmonology",
      image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/pulmonology.webp"
    },
    {
      title: "Psychiatric Medicine / Counselling",
      image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/psychiatric_medicine_counselling.webp"
    },
    {
      title: "Plastic Surgery / Cosmetic Surgery",
      image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/plastic_surgery_cosmetic_surgery.webp"
    },
    {
      title: "Rehabilitation Medicine / Physiotherapy",
      image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/mehabilitation_medicine_physiotherapy.webp"
    },
    {
      title: "Rheumatology",
      image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/rheumatology.webp"
    }
  ];

  const itemsPerSlide = isMobile ? 1 : isTablet ? 2 : 4;

  const slides = [];
  for (let i = 0; i < specialties.length; i += itemsPerSlide) {
    slides.push(specialties.slice(i, i + itemsPerSlide));
  }

  const [activeSlide, setActiveSlide] = useState(0);

  const handleNext = () => {
    setActiveSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
  };

  const handlePrev = () => {
    setActiveSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  };

  return (
    <Container sx={{ py: 5 }} id="ram">
      <Box sx={{ 
        backgroundColor: '#1924aa', 
        color: 'white', 
        display: 'inline-block', 
        px: 2.5, 
        py: 1.25, 
        borderRadius: 1,
        mb: 3
      }}>
        <Typography variant="h5" fontWeight="bold">Our Specialties</Typography>
      </Box>

      <Box sx={{ position: 'relative' }}>
        <Grid container spacing={2} justifyContent="center">
          {slides[activeSlide]?.map((specialty, index) => (
            <Grid item key={index} xs={12} sm={6} md={4} lg={3}>
              <Card sx={{ height: '100%' }}>
                <CardMedia
                  component="img"
                  height="180"
                  image={specialty.image}
                  alt={specialty.title}
                  sx={{ transition: 'transform 0.3s ease-in-out', '&:hover': { transform: 'scale(1.1)' } }}
                />
                <CardContent>
                  <Typography gutterBottom variant="h6" component="div">
                    {specialty.title}
                  </Typography>
                </CardContent>
                <CardActions>
                  <Button size="small">Explore More</Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>

        <IconButton 
          onClick={handlePrev}
          sx={{ 
            position: 'absolute', 
            left: 0, 
            top: '50%', 
            transform: 'translateY(-50%)', 
            backgroundColor: 'rgba(0,0,0,0.5)', 
            color: 'white',
            '&:hover': {
              backgroundColor: 'rgba(0,0,0,0.7)',
            }
          }}
        >
          <ExpandMoreIcon sx={{ transform: 'rotate(90deg)' }} />
        </IconButton>

        <IconButton 
          onClick={handleNext}
          sx={{ 
            position: 'absolute', 
            right: 0, 
            top: '50%', 
            transform: 'translateY(-50%)', 
            backgroundColor: 'rgba(0,0,0,0.5)', 
            color: 'white',
            '&:hover': {
              backgroundColor: 'rgba(0,0,0,0.7)',
            }
          }}
        >
          <ExpandMoreIcon sx={{ transform: 'rotate(-90deg)' }} />
        </IconButton>
      </Box>
    </Container>
  );
};

// Appointment Card Component
const AppointmentCard = () => {
  return (
    <Container sx={{ my: 5 }}>
      <Grid container justifyContent="center">
        <Grid item xs={12} md={10}>
          <Card>
            <Grid container>
              <Grid item xs={12} md={6}>
                <CardMedia
                  component="img"
                  height="400"
                  image="https://t4.ftcdn.net/jpg/09/89/40/13/240_F_989401397_M3ABwyN2Daea1sNuucReswWtYbgMCZsd.jpg"
                  alt="24 Hours service"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <CardContent sx={{ p: 4 }}>
                  <Typography variant="subtitle1" color="text.secondary">
                    24 Hours service
                  </Typography>
                  <Typography variant="h5" component="div" sx={{ mb: 2 }}>
                    Online Appointment
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                    Get all-time support for emergencies. We have introduced the principle of family medicine.
                  </Typography>
                  <Button 
                    variant="contained" 
                    color="primary"
                    component="a"
                    href="appointmentForm.html"
                    sx={{
                      backgroundColor: 'black',
                      color: 'white',
                      '&:hover': {
                        backgroundColor: '#333',
                      }
                    }}
                  >
                    Make an Appointment
                  </Button>
                </CardContent>
              </Grid>
            </Grid>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
};

// Health Check Component
const HealthCheck = () => {
  const [position, setPosition] = useState(0);
  const direction = useRef(1);
  const speed = 0.5;
  const maxHeight = 30;

  useEffect(() => {
    const bounce = () => {
      setPosition(prev => {
        const newPos = prev + direction.current * speed;
        if (newPos >= maxHeight || newPos <= 0) {
          direction.current *= -1;
        }
        return newPos;
      });
      requestAnimationFrame(bounce);
    };

    const animationId = requestAnimationFrame(bounce);
    return () => cancelAnimationFrame(animationId);
  }, []);

  return (
    <Container sx={{ py: 5, backgroundColor: '#fff7f2' }}>
      <Grid container alignItems="center" spacing={4}>
        <Grid item xs={12} md={6}>
          <Typography variant="h3" fontWeight="bold" gutterBottom>
            You Are Unique, Your Health Check Should Be Too!
          </Typography>
          <Typography variant="body1" paragraph>
            Healing hands ProHealth is the world's most advanced health check, crafted by expert doctors and AI. Answer a few questions so we can design an individualized health plan for you with free doctor and specialist consultations included!
          </Typography>
          <Typography variant="h6" gutterBottom>
            Customise Your Unique Health Check
          </Typography>
          <Button 
            variant="contained" 
            size="large"
            href="callback form.html"
            sx={{
              backgroundColor: 'black',
              color: 'white',
              borderRadius: '50px',
              px: 5,
              py: 1.5,
              '&:hover': {
                backgroundColor: '#333',
              }
            }}
          >
            BOOK HEALTH CHECK-UP →
          </Button>
        </Grid>
        <Grid item xs={12} md={6} textAlign="center">
          <Box
            component="img"
            src="https://www.apollohospitals.com/sites/default/files/styles/prohealth_featured/public/2024-12/yoga-girl.png?h=5784954b&itok=dxuy5Bbw"
            alt="Health Check"
            sx={{
              transform: `translateY(-${position}px)`,
              maxWidth: '100%',
              height: 'auto',
            }}
          />
        </Grid>
      </Grid>
    </Container>
  );
};

// Doctors Team Component
const DoctorsTeam = () => {
  const doctors = [
    {
      name: "Dr. Muthu Veeramani",
      title: "Director & Senior Consultant",
      specialty: "Renal Science & Transplantation",
      image: "https://simshospitals.com/wp-content/uploads/2021/09/Dr.-Muthu-Veeramani-Urologist-Chennai.png"
    },
    {
      name: "Dr. R Krishnamoorthy",
      title: "Joint Director and Senior Consultant",
      specialty: "Plastic Surgery",
      image: "https://simshospitals.com/wp-content/uploads/2021/09/Dr.-R-Krishnamoorthy-Plastic-Surgeon-Chennai.png"
    },
    {
      name: "Dr. Vivekanandan Shanmugam",
      title: "Lead Surgeon",
      specialty: "Liver Transplantation",
      image: "https://simshospitals.com/wp-content/uploads/2021/10/Dr.-Vivekanandan-Shanmugam-Liver-Transplant-Surgeon-Chennai.png"
    },
    {
      name: "Dr. K R Suresh Bapu",
      title: "Director & Senior Consultant",
      specialty: "Institute of Neuroscience",
      image: "https://simshospitals.com/wp-content/uploads/2019/07/Dr.-K-R-Suresh-Bapu-Neurosurgeon-Chennai.png"
    },
    {
      name: "Dr. V V Bashi",
      title: "Director & Senior Consultant",
      specialty: "Cardiac & Advanced Aortic Diseases",
      image: "https://simshospitals.com/wp-content/uploads/2021/09/Dr.-V-V-Bashi-Cardiac-Surgeon-Chennai.png"
    },
    {
      name: "Dr. K Sridhar",
      title: "Director & Senior Consultant",
      specialty: "Craniofacial and Plastic Surgery",
      image: "https://simshospitals.com/wp-content/uploads/2021/10/Dr.-K-Sridhar-Plastic-Surgeon-Chennai.png"
    },
    {
      name: "Dr. B S Ramakrishna",
      title: "Director & Senior Consultant",
      specialty: "Gastroenterology",
      image: "https://simshospitals.com/wp-content/uploads/2021/09/Dr.-B-S-Ramakrishna-Medical-Gastroenterologist-Chennai.png"
    },
    {
      name: "Dr. C Vijay Bose",
      title: "Joint Director & Senior Consultant",
      specialty: "Orthopaedic Surgeon",
      image: "https://simshospitals.com/wp-content/uploads/2021/09/Dr.-Vijay-C-Bose-Knee-Replacement-Surgeon-Chennai.png"
    }
  ];

  return (
    <Container sx={{ py: 5 }} id="doc">
      <Typography variant="subtitle1" align="center" gutterBottom>
        Meet Our Experienced Team
      </Typography>
      <Typography variant="h3" align="center" fontWeight="bold" gutterBottom>
        Our Dedicated Doctors Team
      </Typography>
      
      <Grid container spacing={3} sx={{ mt: 2 }}>
        {doctors.map((doctor, index) => (
          <Grid item key={index} xs={12} sm={6} md={4} lg={3}>
            <Paper elevation={3} sx={{ 
              p: 2.5, 
              textAlign: 'center',
              transition: 'transform 0.3s ease-in-out',
              '&:hover': {
                transform: 'translateY(-10px)',
              }
            }}>
              <Avatar
                src={doctor.image}
                alt={doctor.name}
                sx={{ 
                  width: 120, 
                  height: 120, 
                  mx: 'auto',
                  border: '5px solid #e0e0e0',
                  backgroundColor: 'white',
                }}
              />
              <Typography variant="h6" fontWeight="bold" sx={{ mt: 2 }}>
                {doctor.name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {doctor.title}
              </Typography>
              <Typography variant="body2" color="text.primary">
                {doctor.specialty}
              </Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

// Health Articles Component
const HealthArticles = () => {
  const articles = [
    {
      title: "Caring for a Loved One with Alzheimer's Tips for Family Caregivers",
      description: "In the labyrinth of Alzheimer's, family caregivers find themselves as steadfast navigators, embracing both the challenges and the profound moments of connection that come with caring for a loved one with this condition.",
      image: "https://simshospitals.com/homepage/blog1.png"
    },
    {
      title: "The role of physiotherapy in orthopedic recovery",
      description: "In the intricate dance of orthopedic recovery, physiotherapy takes center stage as a guiding partner, offering support, rehabilitation and a pathway to restored mobility. The scope of physiotherapy within orthopedics is vast...",
      image: "https://simshospitals.com/homepage/blog2.png"
    },
    {
      title: "Empower Your Health World Diabetes Day 2023 - Know, Prevent...",
      description: "In the symphony of global health initiatives, World Diabetes Day plays a crucial tune, resonating with millions to 'Know, Prevent, and Control' diabetes. As health-conscious individuals, understanding the significance of...",
      image: "https://simshospitals.com/homepage/blog3.png"
    }
  ];

  return (
    <Container sx={{ py: 5 }}>
      <Box textAlign="center" mb={4}>
        <Typography variant="h3" fontWeight="bold">
          Resources to keep you Healthy
        </Typography>
        <Typography variant="subtitle1" color="text.secondary">
          Blogs and Articles
        </Typography>
      </Box>
      
      <Grid container spacing={3}>
        {articles.map((article, index) => (
          <Grid item key={index} xs={12} md={4}>
            <Card>
              <CardMedia
                component="img"
                height="200"
                image={article.image}
                alt={article.title}
              />
              <CardContent>
                <Typography gutterBottom variant="h6" component="div">
                  {article.title}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {article.description}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

// Stats Counter Component
const StatsCounter = () => {
  const [counters, setCounters] = useState({
    happyPeople: 0,
    surgeryCompleted: 0,
    expertDoctors: 0,
    worldwideBranch: 0
  });

  const targetCounters = {
    happyPeople: 58000,
    surgeryCompleted: 700,
    expertDoctors: 1000,
    worldwideBranch: 200
  };

  const speed = 100; // Lower is faster

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const interval = setInterval(() => {
            setCounters(prev => {
              const newCounters = {...prev};
              let allDone = true;
              
              Object.keys(targetCounters).forEach(key => {
                if (newCounters[key] < targetCounters[key]) {
                  newCounters[key] = Math.min(
                    newCounters[key] + Math.ceil(targetCounters[key] / speed),
                    targetCounters[key]
                  );
                  allDone = false;
                }
              });
              
              if (allDone) {
                clearInterval(interval);
              }
              
              return newCounters;
            });
          }, 20);
          
          return () => clearInterval(interval);
        }
      });
    }, { threshold: 0.5 });

    const element = document.getElementById('stats-section');
    if (element) {
      observer.observe(element);
    }

    return () => {
      if (element) {
        observer.unobserve(element);
      }
    };
  }, []);

  return (
    <Container id="stats-section" sx={{ py: 5, backgroundColor: '#f8f9fa' }}>
      <Grid container textAlign="center" spacing={3}>
        <Grid item xs={6} md={3}>
          <Typography variant="h3" fontWeight="bold">
            {counters.happyPeople.toLocaleString()}
          </Typography>
          <Typography variant="subtitle1">Happy People</Typography>
        </Grid>
        <Grid item xs={6} md={3}>
          <Typography variant="h3" fontWeight="bold">
            {counters.surgeryCompleted.toLocaleString()}
          </Typography>
          <Typography variant="subtitle1">Surgery Completed</Typography>
        </Grid>
        <Grid item xs={6} md={3}>
          <Typography variant="h3" fontWeight="bold">
            {counters.expertDoctors.toLocaleString()}
          </Typography>
          <Typography variant="subtitle1">Expert Doctors</Typography>
        </Grid>
        <Grid item xs={6} md={3}>
          <Typography variant="h3" fontWeight="bold">
            {counters.worldwideBranch.toLocaleString()}
          </Typography>
          <Typography variant="subtitle1">Worldwide Branch</Typography>
        </Grid>
      </Grid>
    </Container>
  );
};

// Services Component
const Services = () => {
  const services = [
    {
      icon: "🧪",
      title: "Laboratory Services",
      description: "We provide quality lab tests with accurate results."
    },
    {
      icon: "❤️",
      title: "Heart Disease",
      description: "Comprehensive heart care treatments and surgery."
    },
    {
      icon: "🦷",
      title: "Dental Care",
      description: "Professional dental services with advanced technology."
    },
    {
      icon: "🩻",
      title: "Body Surgery",
      description: "Advanced surgical procedures with experienced surgeons."
    },
    {
      icon: "🧠",
      title: "Neurology Surgery",
      description: "Expert care for brain and nerve-related conditions."
    },
    {
      icon: "🧬",
      title: "Gynecology",
      description: "Specialized care for women's health and maternity."
    }
  ];

  return (
    <Container sx={{ py: 5 }}>
      <Box textAlign="center" mb={4}>
        <Typography variant="h3" fontWeight="bold">
          Award Winning Patient Care
        </Typography>
        <Typography variant="subtitle1" color="text.secondary">
          We provide top-notch healthcare services with experienced doctors.
        </Typography>
      </Box>
      
      <Grid container spacing={3}>
        {services.map((service, index) => (
          <Grid item key={index} xs={12} sm={6} md={4}>
            <Paper elevation={3} sx={{ 
              p: 2.5, 
              textAlign: 'center',
              transition: 'transform 0.3s ease-in-out',
              '&:hover': {
                transform: 'translateY(-5px)',
              }
            }}>
              <Typography variant="h3" sx={{ mb: 1 }}>
                {service.icon}
              </Typography>
              <Typography variant="h6" fontWeight="bold">
                {service.title}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {service.description}
              </Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

// Locations Component
const Locations = () => {
  const locations = [
    {
      name: "Chennai Alwarpet",
      image: "https://ehealth.eletsonline.com/wp-content/uploads/2009/07/best-hospital-in-south-india.jpg"
    },
    {
      name: "Chennai Radial Road",
      image: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Hospital-de-Bellvitge.jpg/640px-Hospital-de-Bellvitge.jpg"
    },
    {
      name: "Chennai Vadapalani",
      image: "https://www.myhospitalnow.com/blog/wp-content/uploads/2024/04/image-209.png"
    },
    {
      name: "Trichy - Cantonment",
      image: "https://cdn.britannica.com/12/130512-004-AD0A7CA4/campus-Riverside-Ottawa-The-Hospital-Ont.jpg"
    },
    {
      name: "Trichy - Heart City",
      image: "https://advinhealthcare.com/wp-content/uploads/2022/12/Types-of-Hospitals-2.jpg"
    },
    {
      name: "Trichy - Tennur",
      image: "https://purplecentre.com/wp-content/uploads/2017/04/Hospital.jpg"
    },
    {
      name: "Tirunelveli",
      image: "https://i.vimeocdn.com/video/1947651283-683b95ec53d4efd8768a580dfeb22bc654eb0e51e2ee5764e6f0346d797aa585-d?f=webp"
    },
    {
      name: "Hosur",
      image: "https://www.shutterstock.com/shutterstock/photos/2240217303/display_1500/stock-photo-modern-public-hospital-building-d-illustration-2240217303.jpg"
    }
  ];

  return (
    <Container sx={{ py: 5 }}>
      <Grid container alignItems="center" spacing={4}>
        <Grid item xs={12} md={3} textAlign={{ xs: 'center', md: 'left' }}>
          <Box sx={{ fontSize: 50, color: '#ff4081', mb: 2 }}>
            <PlaceIcon fontSize="inherit" />
          </Box>
          <Typography variant="h4" fontWeight="bold">
            Expert healthcare, <br /> closer to you.
          </Typography>
        </Grid>
        
        <Grid item xs={12} md={9}>
          <Grid container spacing={3}>
            {locations.map((location, index) => (
              <Grid item key={index} xs={6} sm={4} md={3}>
                <Card className="custom-card">
                  <CardMedia
                    component="img"
                    height="140"
                    image={location.image}
                    alt={location.name}
                  />
                  <CardContent sx={{ textAlign: 'center', fontWeight: 'bold' }}>
                    {location.name}
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Grid>
      </Grid>
    </Container>
  );
};

// Contact Us Component
const ContactUs = () => {
  return (
    <Container sx={{ py: 5 }} id="contact">
      <Box sx={{ maxWidth: 800, mx: 'auto' }}>
        <Typography variant="h4" fontWeight="bold" gutterBottom>
          Get in touch
        </Typography>
        
        <Typography variant="h6" gutterBottom>
          Address:
        </Typography>
        <Typography paragraph>
          Healing hand International <br />
          4/112, Mount Poonamallee Road, <br />
          Manapakkam, Chennai - 600 089 <br />
          Tamil Nadu, INDIA
        </Typography>
        
        <Typography variant="h6" gutterBottom>
          Email:
        </Typography>
        <Link href="mailto:hand2485@gmail.com" color="primary">
          hand2485@gmail.com
        </Link>
        
        <Typography variant="h6" gutterBottom sx={{ mt: 2 }}>
          Phone:
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <PhoneIcon sx={{ mr: 1 }} />
          <Link href="tel:+914442002288" color="primary">
            +91 44 42002288
          </Link>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <PhoneIcon sx={{ mr: 1 }} />
          <Link href="tel:+914422492288" color="primary">
            +91 44 22492288
          </Link>
        </Box>
        
        <Typography variant="h6" gutterBottom sx={{ mt: 2 }}>
          Fax:
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <FaxIcon sx={{ mr: 1 }} />
          <Typography>+91 44 22491188, +91 44 22491313</Typography>
        </Box>
      </Box>
    </Container>
  );
};

// Footer Component
const Footer = () => {
  return (
    <Box component="footer" sx={{ 
      backgroundColor: '#2C2F3F', 
      color: 'white