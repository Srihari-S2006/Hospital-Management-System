import React, { useState } from 'react';
import {
  Box,
  Typography,
  Container,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Button,
  Grid,
  Card,
  CardContent,
  TextField,
  MenuItem,
  Alert,
  Stack,
  useTheme,
  useMediaQuery,
  Paper
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import WarningIcon from '@mui/icons-material/Warning';
import PhoneIcon from '@mui/icons-material/Phone';
import EmailIcon from '@mui/icons-material/Email';
import LocationOnIcon from '@mui/icons-material/LocationOn';

// Define theme colors
const colors = {
  primaryBlue: '#005b9f',
  secondaryBlue: '#0077cc',
  lightBlue: '#e6f2ff',
  darkBlue: '#003366',
  accentRed: '#e63946',
  white: '#ffffff',
  lightGray: '#f5f5f5',
  textColor: '#333333',
};

const FAQPage = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [activeCategory, setActiveCategory] = useState('all');

  // FAQ Categories
  const categories = [
    { id: 'all', label: 'All Questions' },
    { id: 'appointments', label: 'Appointments' },
    { id: 'billing', label: 'Billing & Insurance' },
    { id: 'visitors', label: 'Visitors & Policies' },
    { id: 'medical', label: 'Medical Services' },
    { id: 'covid', label: 'COVID-19' },
  ];

  // FAQ Data
  const faqData = [
    {
      id: 'appointments',
      title: 'Appointment Questions',
      questions: [
        {
          id: 'appointment1',
          question: 'How do I book an appointment?',
          answer: (
            <>
              <Typography>You can book an appointment in several ways:</Typography>
              <ul>
                <li>Online through our patient portal</li>
                <li>By calling our appointment desk at (555) 123-4567</li>
                <li>In person at our reception desk</li>
                <li>Through our mobile app (available on iOS and Android)</li>
              </ul>
              <Typography>New patients will need to complete registration forms before their first visit.</Typography>
            </>
          ),
        },
        {
          id: 'appointment2',
          question: 'What should I bring to my first appointment?',
          answer: (
            <>
              <Typography>For your first appointment, please bring:</Typography>
              <ul>
                <li>Photo ID (driver's license, passport, etc.)</li>
                <li>Insurance card (if applicable)</li>
                <li>List of current medications</li>
                <li>Medical records from previous providers (if available)</li>
                <li>Payment method for any copays or deductibles</li>
              </ul>
            </>
          ),
        },
        {
          id: 'appointment3',
          question: 'How do I cancel or reschedule an appointment?',
          answer: (
            <>
              <Typography>You can cancel or reschedule appointments:</Typography>
              <ul>
                <li>Online through your patient portal account</li>
                <li>By calling our appointment desk at least 24 hours in advance</li>
                <li>Through our mobile app</li>
              </ul>
              <Typography color="error">
                Please note that repeated no-shows or late cancellations may result in fees.
              </Typography>
            </>
          ),
        },
      ],
    },
    {
      id: 'billing',
      title: 'Billing & Insurance',
      questions: [
        {
          id: 'billing1',
          question: 'What insurance plans do you accept?',
          answer: (
            <>
              <Typography>We accept most major insurance plans including:</Typography>
              <ul>
                <li>Blue Cross Blue Shield</li>
                <li>Aetna</li>
                <li>Cigna</li>
                <li>United Healthcare</li>
                <li>Medicare</li>
                <li>Medicaid</li>
                <li>Many regional and employer-sponsored plans</li>
              </ul>
              <Typography>
                Please contact our billing department at (555) 123-4568 to verify if we accept your specific plan.
              </Typography>
            </>
          ),
        },
        {
          id: 'billing2',
          question: 'What payment options are available?',
          answer: (
            <>
              <Typography>We offer several payment options for your convenience:</Typography>
              <ul>
                <li>Credit/debit cards (Visa, MasterCard, American Express, Discover)</li>
                <li>Personal checks</li>
                <li>Cash</li>
                <li>Health savings account (HSA) cards</li>
                <li>Payment plans for larger balances</li>
              </ul>
              <Typography>
                You can pay online through our patient portal, by phone, or in person at our billing office.
              </Typography>
            </>
          ),
        },
      ],
    },
    {
      id: 'visitors',
      title: 'Visitors & Policies',
      questions: [
        {
          id: 'visitors1',
          question: 'What are your visiting hours?',
          answer: (
            <>
              <Typography>Our general visiting hours are:</Typography>
              <ul>
                <li><strong>General Wards:</strong> 10:00 AM - 8:00 PM (2 visitors at a time)</li>
                <li><strong>ICU:</strong> 11:00 AM - 1:00 PM and 5:00 PM - 7:00 PM (immediate family only, 1 visitor at a time)</li>
                <li><strong>Maternity:</strong> 9:00 AM - 9:00 PM (partners have 24-hour access)</li>
                <li><strong>Pediatrics:</strong> 10:00 AM - 8:00 PM (parents may stay overnight)</li>
              </ul>
              <Typography>Special arrangements can be made for extenuating circumstances.</Typography>
            </>
          ),
        },
      ],
    },
    {
      id: 'medical',
      title: 'Medical Services',
      questions: [
        {
          id: 'medical1',
          question: 'How do I get my medical records?',
          answer: (
            <>
              <Typography>You can request your medical records through:</Typography>
              <ul>
                <li><strong>Online:</strong> Through our patient portal</li>
                <li><strong>In Person:</strong> At our medical records office (bring photo ID)</li>
                <li><strong>By Mail/Fax:</strong> Complete an authorization form and send to our records department</li>
              </ul>
              <Typography>There may be fees for copies of records depending on the request type and volume.</Typography>
            </>
          ),
        },
      ],
    },
    {
      id: 'covid',
      title: 'COVID-19 Information',
      questions: [
        {
          id: 'covid1',
          question: 'What are your current COVID-19 policies?',
          answer: (
            <>
              <Typography>Our current COVID-19 policies include:</Typography>
              <ul>
                <li>Masks are optional but recommended in patient care areas</li>
                <li>Enhanced cleaning protocols throughout the facility</li>
                <li>Visitor restrictions may be implemented during outbreaks</li>
                <li>COVID-19 testing available for symptomatic patients</li>
                <li>Vaccination clinics held monthly</li>
              </ul>
              <Typography>These policies are subject to change based on community transmission levels.</Typography>
            </>
          ),
        },
      ],
    },
  ];

  // Filter questions based on active category
  const getFilteredQuestions = () => {
    if (activeCategory === 'all') {
      return faqData;
    }
    return faqData.filter(section => section.id === activeCategory);
  };

  return (
    <Box sx={{ bgcolor: colors.lightGray, minHeight: '100vh' }}>
      {/* Hero Section */}
      <Box
        sx={{
          background: `linear-gradient(rgba(0, 91, 159, 0.8), rgba(0, 51, 102, 0.8))`,
          color: 'white',
          py: { xs: 8, md: 12 },
          textAlign: 'center',
        }}
      >
        <Container>
          <Typography variant="h2" component="h1" fontWeight="bold" gutterBottom>
            Frequently Asked Questions
          </Typography>
          <Typography variant="h6">
            Find answers to common questions about our hospital services and policies
          </Typography>
        </Container>
      </Box>

      {/* FAQ Categories */}
      <Paper elevation={2} sx={{ bgcolor: colors.white, py: 3 }}>
        <Container>
          <Stack 
            direction="row" 
            spacing={1} 
            justifyContent="center" 
            flexWrap="wrap" 
            useFlexGap
            sx={{ gap: 1 }}
          >
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={activeCategory === category.id ? 'contained' : 'outlined'}
                color="primary"
                onClick={() => setActiveCategory(category.id)}
                sx={{
                  mb: { xs: 1, md: 0 },
                  bgcolor: activeCategory === category.id ? colors.primaryBlue : colors.lightBlue,
                  color: activeCategory === category.id ? colors.white : colors.primaryBlue,
                  '&:hover': {
                    bgcolor: colors.primaryBlue,
                    color: colors.white,
                  },
                }}
              >
                {category.label}
              </Button>
            ))}
          </Stack>
        </Container>
      </Paper>

      {/* FAQ Accordion Section */}
      <Container sx={{ py: 6 }}>
        <Grid container justifyContent="center">
          <Grid item xs={12} md={10} lg={8}>
            {getFilteredQuestions().map((section) => (
              <Box key={section.id} sx={{ mb: 5 }}>
                <Typography
                  variant="h5"
                  component="h3"
                  color="primary"
                  fontWeight="bold"
                  id={section.id}
                  sx={{ mb: 3 }}
                >
                  {section.title}
                </Typography>
                {section.questions.map((item) => (
                  <Accordion
                    key={item.id}
                    sx={{
                      mb: 2,
                      borderRadius: 1,
                      overflow: 'hidden',
                      '&:before': {
                        display: 'none',
                      },
                    }}
                  >
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      sx={{
                        bgcolor: 'white',
                        color: colors.primaryBlue,
                        fontWeight: 'bold',
                        '&.Mui-expanded': {
                          bgcolor: colors.lightBlue,
                          color: colors.primaryBlue,
                        },
                      }}
                    >
                      <Typography fontWeight="600">{item.question}</Typography>
                    </AccordionSummary>
                    <AccordionDetails sx={{ bgcolor: 'white', p: 3 }}>
                      {item.answer}
                    </AccordionDetails>
                  </Accordion>
                ))}
              </Box>
            ))}

            {/* Emergency Box */}
            <Alert
              severity="error"
              icon={<WarningIcon />}
              sx={{
                bgcolor: '#fff3f3',
                borderLeft: `4px solid ${colors.accentRed}`,
                my: 5,
                p: 3,
                borderRadius: 1,
                '& .MuiAlert-message': { width: '100%' },
              }}
            >
              <Typography variant="h6" component="h4" sx={{ mb: 1 }}>
                Emergency Information
              </Typography>
              <Typography>
                For medical emergencies, please call <strong>911</strong> or go to the nearest emergency room.
              </Typography>
              <Typography sx={{ mt: 1 }}>
                Our Emergency Department is open 24/7 at our main hospital location:
              </Typography>
              <Typography sx={{ mt: 1 }}>
                <strong>Address:</strong> 123 Wellness Boulevard, Medicity, MC 12345
              </Typography>
              <Typography>
                <strong>Emergency Phone:</strong> (555) 911-9111
              </Typography>
            </Alert>
          </Grid>
        </Grid>
      </Container>

      {/* Contact Section */}
      <Box sx={{ bgcolor: colors.lightBlue, py: 6 }}>
        <Container>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Card sx={{ height: '100%' }}>
                <CardContent sx={{ p: 4 }}>
                  <Typography variant="h5" component="h3" sx={{ mb: 3 }}>
                    Still Have Questions?
                  </Typography>
                  <Typography>
                    If you couldn't find the answer you were looking for, our patient relations team is happy to help.
                  </Typography>
                  <Box sx={{ mt: 3 }}>
                    <Stack direction="row" spacing={2} alignItems="center" sx={{ mb: 2 }}>
                      <PhoneIcon color="primary" />
                      <Typography>
                        <strong>Phone:</strong> (555) 123-4567
                      </Typography>
                    </Stack>
                    <Stack direction="row" spacing={2} alignItems="center" sx={{ mb: 2 }}>
                      <EmailIcon color="primary" />
                      <Typography>
                        <strong>Email:</strong> info@healinghandshospital.com
                      </Typography>
                    </Stack>
                    <Stack direction="row" spacing={2} alignItems="center">
                      <LocationOnIcon color="primary" />
                      <Typography>
                        <strong>Address:</strong> 123 Wellness Boulevard, Medicity, MC 12345
                      </Typography>
                    </Stack>
                  </Box>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={6}>
              <Card>
                <CardContent sx={{ p: 4 }}>
                  <Typography variant="h5" component="h3" sx={{ mb: 3 }}>
                    Send Us a Message
                  </Typography>
                  <form>
                    <TextField
                      label="Your Name"
                      fullWidth
                      margin="normal"
                      required
                      size="small"
                    />
                    <TextField
                      label="Email Address"
                      fullWidth
                      margin="normal"
                      type="email"
                      required
                      size="small"
                    />
                    <TextField
                      select
                      label="Question Category"
                      fullWidth
                      margin="normal"
                      defaultValue="General Inquiry"
                      size="small"
                    >
                      <MenuItem value="General Inquiry">General Inquiry</MenuItem>
                      <MenuItem value="Billing Question">Billing Question</MenuItem>
                      <MenuItem value="Appointment Help">Appointment Help</MenuItem>
                      <MenuItem value="Medical Records">Medical Records</MenuItem>
                      <MenuItem value="Other">Other</MenuItem>
                    </TextField>
                    <TextField
                      label="Your Question"
                      fullWidth
                      margin="normal"
                      multiline
                      rows={4}
                      required
                      size="small"
                    />
                    <Button
                      type="submit"
                      variant="contained"
                      color="primary"
                      sx={{ mt: 2 }}
                    >
                      Submit Question
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </Box>
  );
};

export default FAQPage;