import React from 'react';
import { 
  Box,
  Container, 
  Typography, 
  Paper, 
  List, 
  ListItem, 
  ListItemIcon, 
  ListItemText,
  Card,
  CardContent,
  Tabs,
  Tab,
  useTheme,
  useMediaQuery,
  Divider
} from '@mui/material';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';

// TabPanel component to handle tab content
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`privacy-tabpanel-${index}`}
      aria-labelledby={`privacy-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ py: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

// Helper function for tab accessibility
function a11yProps(index) {
  return {
    id: `privacy-tab-${index}`,
    'aria-controls': `privacy-tabpanel-${index}`,
  };
}

function PrivacyPolicy() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  // Custom list item with bullet points
  const BulletListItem = ({ text }) => (
    <ListItem disableGutters>
      <ListItemIcon sx={{ minWidth: 28 }}>
        <FiberManualRecordIcon color="primary" fontSize="small" />
      </ListItemIcon>
      <ListItemText primary={text} />
    </ListItem>
  );

  // Highlighted box component
  const HighlightBox = ({ children }) => (
    <Box
      sx={{
        backgroundColor: theme.palette.primary.light,
        borderLeft: `4px solid ${theme.palette.error.main}`,
        borderRadius: '0 6px 6px 0',
        padding: 3,
        margin: '16px 0',
      }}
    >
      {children}
    </Box>
  );

  return (
    <Box>
      {/* Header */}
      <Box
        sx={{
          background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.grey[900]})`,
          color: 'white',
          py: { xs: 5, md: 8 },
          position: 'relative',
          overflow: 'hidden',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            opacity: 0.1,
            zIndex: 1,
            bgcolor: 'rgba(0,0,0,0.3)'
          }
        }}
      >
        <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 2, textAlign: 'center' }}>
          <Typography variant="h2" component="h1" gutterBottom fontWeight="bold">
            Privacy Policy
          </Typography>
          <Typography variant="h6" sx={{ maxWidth: 700, mx: 'auto', opacity: 0.9 }}>
            At Healing Hands Hospital, we are committed to protecting your personal and health information with the highest standards of privacy and security.
          </Typography>
        </Container>
      </Box>

      {/* Main Content */}
      <Container maxWidth="lg" sx={{ mt: -4, mb: 5, position: 'relative', zIndex: 10 }}>
        <Paper 
          elevation={3} 
          sx={{ 
            borderRadius: 2,
            overflow: 'hidden'
          }}
        >
          {/* Navigation Tabs */}
          <Box sx={{ bgcolor: 'primary.light' }}>
            <Tabs
              value={value}
              onChange={handleChange}
              variant={isMobile ? "scrollable" : "fullWidth"}
              scrollButtons="auto"
              aria-label="privacy policy tabs"
              sx={{ borderBottom: 1, borderColor: 'divider' }}
            >
              <Tab label="Introduction" {...a11yProps(0)} />
              <Tab label="Information We Collect" {...a11yProps(1)} />
              <Tab label="How We Use Information" {...a11yProps(2)} />
              <Tab label="Information Sharing" {...a11yProps(3)} />
              <Tab label="Your Rights" {...a11yProps(4)} />
              <Tab label="Security" {...a11yProps(5)} />
              <Tab label="Contact Us" {...a11yProps(6)} />
            </Tabs>
          </Box>

          {/* Content Sections */}
          <Box sx={{ px: { xs: 2, md: 5 }, py: 4 }}>
            <TabPanel value={value} index={0}>
              <Typography variant="h4" component="h2" color="primary" gutterBottom>
                Our Commitment to Your Privacy
              </Typography>
              <Typography paragraph>
                Healing Hands Hospital is dedicated to maintaining the privacy of your protected health information (PHI). This Privacy Policy describes how we may use and disclose your PHI and how you can access this information. Our practices are designed to comply with the Health Insurance Portability and Accountability Act (HIPAA) and other applicable laws.
              </Typography>
              <HighlightBox>
                <Typography variant="body1" fontWeight="medium">
                  Please review this policy carefully. By using our services, you acknowledge you have read and understood this Privacy Policy.
                </Typography>
              </HighlightBox>
            </TabPanel>

            <TabPanel value={value} index={1}>
              <Typography variant="h4" component="h2" color="primary" gutterBottom>
                Information We Collect
              </Typography>
              <Typography paragraph>
                We collect various types of information to provide quality healthcare services:
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Personal Information
              </Typography>
              <List dense>
                <BulletListItem text="Name, contact details, date of birth, and identification numbers" />
                <BulletListItem text="Insurance and payment information" />
                <BulletListItem text="Emergency contact details" />
              </List>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Health Information
              </Typography>
              <List dense>
                <BulletListItem text="Medical history and current health conditions" />
                <BulletListItem text="Diagnoses, treatment plans, and progress notes" />
                <BulletListItem text="Laboratory and test results" />
                <BulletListItem text="Medication records" />
              </List>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Technical Information
              </Typography>
              <List dense>
                <BulletListItem text="Website usage data through cookies" />
                <BulletListItem text="IP addresses and device information" />
                <BulletListItem text="Patient portal activity logs" />
              </List>
            </TabPanel>

            <TabPanel value={value} index={2}>
              <Typography variant="h4" component="h2" color="primary" gutterBottom>
                How We Use Your Information
              </Typography>
              <Typography paragraph>
                Your information helps us provide and improve our services:
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Treatment
              </Typography>
              <Typography paragraph>
                To provide, coordinate, and manage your healthcare with our medical team and other providers.
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Payment
              </Typography>
              <Typography paragraph>
                To bill and collect payment from you, your insurance company, or other third parties.
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Healthcare Operations
              </Typography>
              <Typography paragraph>
                To improve quality, train staff, conduct audits, and manage our organization.
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Other Uses
              </Typography>
              <List dense>
                <BulletListItem text="Appointment reminders and health notifications" />
                <BulletListItem text="Treatment alternatives and health-related benefits" />
                <BulletListItem text="Medical research (with appropriate consent)" />
                <BulletListItem text="As required by law or public health authorities" />
              </List>
            </TabPanel>

            <TabPanel value={value} index={3}>
              <Typography variant="h4" component="h2" color="primary" gutterBottom>
                Information Sharing and Disclosure
              </Typography>
              <Typography paragraph>
                We may share your information in these circumstances:
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                With Healthcare Providers
              </Typography>
              <Typography paragraph>
                To other doctors, specialists, and facilities involved in your care.
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                For Payment
              </Typography>
              <Typography paragraph>
                To insurance companies and other payers to process claims.
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Required by Law
              </Typography>
              <Typography paragraph>
                When required by court orders, public health reporting, or law enforcement.
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Business Associates
              </Typography>
              <Typography paragraph>
                To vendors who help us operate, all bound by confidentiality agreements.
              </Typography>
              
              <HighlightBox>
                <Typography variant="body1">
                  We <strong>do not</strong> sell patient information to marketers or third parties unrelated to your treatment.
                </Typography>
              </HighlightBox>
            </TabPanel>

            <TabPanel value={value} index={4}>
              <Typography variant="h4" component="h2" color="primary" gutterBottom>
                Your Privacy Rights
              </Typography>
              <Typography paragraph>
                You have important rights regarding your health information:
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Access and Copies
              </Typography>
              <Typography paragraph>
                Request to see and get copies of your health records.
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Corrections
              </Typography>
              <Typography paragraph>
                Request amendments to incorrect or incomplete information.
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Restrictions
              </Typography>
              <Typography paragraph>
                Ask us to limit how we use or share your information.
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Confidential Communications
              </Typography>
              <Typography paragraph>
                Request we contact you in specific ways (e.g., only at certain numbers).
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Complaints
              </Typography>
              <Typography paragraph>
                File a complaint if you believe your privacy rights were violated.
              </Typography>
            </TabPanel>

            <TabPanel value={value} index={5}>
              <Typography variant="h4" component="h2" color="primary" gutterBottom>
                Our Security Measures
              </Typography>
              <Typography paragraph>
                We implement robust safeguards to protect your information:
              </Typography>
              
              <List dense>
                <BulletListItem text="Advanced encryption for electronic records" />
                <BulletListItem text="Secure access controls and authentication" />
                <BulletListItem text="Regular staff training on privacy practices" />
                <BulletListItem text="Physical security for paper records" />
                <BulletListItem text="Ongoing risk assessments and audits" />
              </List>
              
              <Typography variant="h4" component="h2" color="primary" sx={{ mt: 4, mb: 2 }}>
                Website and Digital Privacy
              </Typography>
              <Typography paragraph>
                Our online services have additional protections:
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Cookies and Tracking
              </Typography>
              <Typography paragraph>
                We use essential cookies for functionality and analytics to improve our website.
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Patient Portal
              </Typography>
              <Typography paragraph>
                Our secure portal uses multi-factor authentication to protect your health data.
              </Typography>
              
              <Typography variant="h5" component="h3" sx={{ mt: 3, mb: 2 }}>
                Third-Party Services
              </Typography>
              <Typography paragraph>
                Some services (like payment processors) have their own privacy policies.
              </Typography>
              
              <Typography variant="h4" component="h2" color="primary" sx={{ mt: 4, mb: 2 }}>
                Policy Changes
              </Typography>
              <Typography paragraph>
                We may update this policy periodically. The updated version will be posted on our website with a new effective date. For significant changes, we will notify patients as required by law.
              </Typography>
            </TabPanel>

            <TabPanel value={value} index={6}>
              <Card sx={{ mb: 3, bgcolor: 'background.paper' }}>
                <CardContent>
                  <Typography variant="h4" component="h2" color="primary" gutterBottom>
                    Contact Our Privacy Team
                  </Typography>
                  <Typography variant="h5" component="h3" sx={{ mt: 2, mb: 1 }}>
                    Privacy Officer
                  </Typography>
                  <Typography paragraph>
                    Healing Hands Hospital<br />
                    123 Wellness Boulevard<br />
                    Medicity, MC 12345
                  </Typography>
                  
                  <Typography paragraph>
                    <strong>Phone:</strong> (555) 123-4590<br />
                    <strong>Email:</strong> privacy@healinghandshospital.com
                  </Typography>
                  
                  <Typography paragraph>
                    For complaints, you may also contact:<br />
                    U.S. Department of Health and Human Services<br />
                    Office for Civil Rights
                  </Typography>
                </CardContent>
              </Card>
            </TabPanel>

            <Box sx={{ mt: 4, textAlign: 'right', color: 'text.secondary', fontStyle: 'italic' }}>
              <Typography variant="body2">
                Effective Date: January 15, 2023 | Last Updated: June 1, 2023
              </Typography>
            </Box>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
}

export default PrivacyPolicy;