import React, { useState } from 'react';
import { 
  Container,
  Card,
  Typography,
  TextField,
  Button,
  Box,
  Grid,
  Divider,
  IconButton,
  useTheme,
  Link
} from '@mui/material';
import {
  Apple as AppleIcon,
  Android as AndroidIcon,
  Facebook as FacebookIcon,
  Twitter as TwitterIcon,
  LinkedIn as LinkedInIcon,
  WhatsApp as WhatsAppIcon
} from '@mui/icons-material';

const AppointmentForm = () => {
  const theme = useTheme();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: '',
    message: ''
  });
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const phoneRegex = /^\d{10}$/;

    if (formData.name.length < 3 || formData.name.length > 50) {
      newErrors.name = "Full Name must be between 3 and 50 characters.";
    }

    if (!emailRegex.test(formData.email)) {
      newErrors.email = "Please enter a valid email address.";
    }

    if (!phoneRegex.test(formData.phone)) {
      newErrors.phone = "Phone Number must be exactly 10 digits.";
    }

    if (!formData.date) {
      newErrors.date = "Appointment Date is required.";
    }

    if (!formData.time) {
      newErrors.time = "Appointment Time is required.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      alert("Form submitted successfully!");
      // Here you would typically send the data to your backend
      console.log(formData);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <Box sx={{
      backgroundImage: 'url(https://img.freepik.com/free-photo/doctor-with-digital-tablet_1098-18240.jpg)',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      minHeight: '100vh',
      fontFamily: 'Arial, sans-serif'
    }}>
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Card sx={{ 
          p: 4, 
          boxShadow: 3,
          maxWidth: 500,
          mx: 'auto',
          backgroundColor: 'rgba(255, 255, 255, 0.95)'
        }}>
          <Typography variant="h4" align="center" gutterBottom sx={{ fontWeight: 'bold' }}>
            Book an Appointment
          </Typography>
          
          <form onSubmit={handleSubmit}>
            <TextField
              fullWidth
              label="Full Name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              margin="normal"
              error={!!errors.name}
              helperText={errors.name}
              placeholder="Enter your name"
            />
            
            <TextField
              fullWidth
              label="Email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              margin="normal"
              error={!!errors.email}
              helperText={errors.email}
              placeholder="Enter your email"
            />
            
            <TextField
              fullWidth
              label="Phone Number"
              name="phone"
              type="tel"
              value={formData.phone}
              onChange={handleChange}
              margin="normal"
              error={!!errors.phone}
              helperText={errors.phone}
              placeholder="Enter your phone number"
            />
            
            <TextField
              fullWidth
              label="Appointment Date"
              name="date"
              type="date"
              value={formData.date}
              onChange={handleChange}
              margin="normal"
              InputLabelProps={{ shrink: true }}
              error={!!errors.date}
              helperText={errors.date}
            />
            
            <TextField
              fullWidth
              label="Appointment Time"
              name="time"
              type="time"
              value={formData.time}
              onChange={handleChange}
              margin="normal"
              InputLabelProps={{ shrink: true }}
              error={!!errors.time}
              helperText={errors.time}
            />
            
            <TextField
              fullWidth
              label="Message (Optional)"
              name="message"
              value={formData.message}
              onChange={handleChange}
              margin="normal"
              multiline
              rows={3}
              placeholder="Additional details"
            />
            
            <Button
              type="submit"
              variant="contained"
              fullWidth
              size="large"
              sx={{ mt: 3 }}
            >
              Submit Appointment
            </Button>
          </form>
        </Card>
      </Container>

      
    </Box>
  );
};

export default AppointmentForm;