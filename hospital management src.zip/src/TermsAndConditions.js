import React, { useState } from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Paper, 
  Tabs, 
  Tab, 
  List, 
  ListItem, 
  ListItemText, 
  Divider, 
  Alert, 
  useTheme, 
  useMediaQuery 
} from '@mui/material';
import { styled } from '@mui/material/styles';

// Styled components
const HeaderBox = styled(Box)(({ theme }) => ({
  background: `linear-gradient(135deg, #005b9f, #003366)`,
  color: '#ffffff',
  padding: theme.spacing(8, 0),
  textAlign: 'center',
  marginBottom: theme.spacing(4),
}));

const NoticeBox = styled(Box)(({ theme }) => ({
  backgroundColor: '#e6f2ff',
  borderLeft: '4px solid #005b9f',
  padding: theme.spacing(3),
  margin: theme.spacing(4, 0),
  borderRadius: '0 4px 4px 0',
}));

const WarningBox = styled(Box)(({ theme }) => ({
  backgroundColor: '#fff3f3',
  borderLeft: '4px solid #ff6b6b',
  padding: theme.spacing(3),
  margin: theme.spacing(4, 0),
  borderRadius: '0 4px 4px 0',
}));

const SectionTitle = styled(Typography)(({ theme }) => ({
  color: '#005b9f',
  fontSize: '1.8rem',
  marginTop: theme.spacing(5),
  marginBottom: theme.spacing(3),
  paddingBottom: theme.spacing(1),
  borderBottom: '2px solid #e6f2ff',
}));

const SubSectionTitle = styled(Typography)(({ theme }) => ({
  color: '#003366',
  fontSize: '1.4rem',
  marginTop: theme.spacing(4),
  marginBottom: theme.spacing(2),
}));

const UpdateDate = styled(Typography)(({ theme }) => ({
  textAlign: 'right',
  color: '#333333',
  fontStyle: 'italic',
  marginTop: theme.spacing(4),
  opacity: 0.8,
}));

function TermsAndConditions() {
  const [value, setValue] = useState(0);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const sections = [
    { label: 'Acceptance', id: 'acceptance' },
    { label: 'Services', id: 'services' },
    { label: 'Responsibilities', id: 'responsibilities' },
    { label: 'Privacy', id: 'privacy' },
    { label: 'Payments', id: 'payments' },
    { label: 'Liability', id: 'liability' },
  ];

  const handleChange = (event, newValue) => {
    setValue(newValue);
    const element = document.getElementById(sections[newValue].id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <Box sx={{ bgcolor: '#f5f5f5', minHeight: '100vh', pb: 6 }}>
      <HeaderBox>
        <Container maxWidth="lg">
          <Typography variant="h3" component="h1" gutterBottom>
            Terms and Conditions
          </Typography>
          <Typography variant="h6">
            Governing your use of Healing Hands Hospital services and facilities
          </Typography>
        </Container>
      </HeaderBox>

      <Container maxWidth="lg">
        <Paper 
          elevation={3} 
          sx={{ 
            borderRadius: 2, 
            overflow: 'hidden',
            mt: -6,
            mb: 6 
          }}
        >
          <Box sx={{ bgcolor: '#e6f2ff', px: 3, py: 2, borderBottom: '1px solid #e0e0e0' }}>
            <Tabs 
              value={value} 
              onChange={handleChange}
              variant={isMobile ? "scrollable" : "standard"}
              scrollButtons={isMobile ? "auto" : false}
              allowScrollButtonsMobile
              aria-label="terms navigation tabs"
            >
              {sections.map((section, index) => (
                <Tab key={index} label={section.label} />
              ))}
            </Tabs>
          </Box>

          <Box sx={{ p: { xs: 3, md: 6 } }}>
            <Box id="introduction">
              <SectionTitle variant="h4" component="h2">
                Introduction
              </SectionTitle>
              <Typography paragraph>
                Welcome to Healing Hands Hospital. These Terms and Conditions outline the rules and regulations 
                governing your use of our healthcare services, facilities, and website.
              </Typography>
              
              <NoticeBox>
                <Typography>
                  By accessing or using our services, you accept these terms in full. If you disagree with any 
                  part of these terms, you must not use our services.
                </Typography>
              </NoticeBox>
            </Box>
            
            <Box id="acceptance">
              <SectionTitle variant="h4" component="h2">
                Acceptance of Terms
              </SectionTitle>
              <Typography paragraph>
                Your use of our services constitutes agreement to:
              </Typography>
              <List disablePadding>
                <ListItem>
                  <ListItemText primary="These Terms and Conditions" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Our Privacy Policy" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="All applicable hospital policies and procedures" />
                </ListItem>
              </List>
              
              <SubSectionTitle variant="h5" component="h3">
                Updates to Terms
              </SubSectionTitle>
              <Typography paragraph>
                We may revise these terms at any time. The updated version will be posted on our website with the effective date.
              </Typography>
            </Box>
            
            <Box id="services">
              <SectionTitle variant="h4" component="h2">
                Medical Services
              </SectionTitle>
              <SubSectionTitle variant="h5" component="h3">
                Scope of Care
              </SubSectionTitle>
              <Typography paragraph>
                We provide comprehensive healthcare services including:
              </Typography>
              <List disablePadding>
                <ListItem>
                  <ListItemText primary="Emergency treatment" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Inpatient and outpatient care" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Surgical services" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Diagnostic testing" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Specialty consultations" />
                </ListItem>
              </List>
              
              <WarningBox>
                <Typography>
                  <strong>Medical Disclaimer:</strong> While we strive for excellence, we cannot guarantee specific treatment outcomes. Individual results may vary.
                </Typography>
              </WarningBox>
            </Box>
            
            <Box id="responsibilities">
              <SectionTitle variant="h4" component="h2">
                Patient Responsibilities
              </SectionTitle>
              <Typography paragraph>
                As a patient, you agree to:
              </Typography>
              <List disablePadding>
                <ListItem>
                  <ListItemText primary="Provide accurate medical history" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Follow treatment plans" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Keep scheduled appointments" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Treat staff with respect" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Comply with all hospital policies" />
                </ListItem>
              </List>
              
              <SubSectionTitle variant="h5" component="h3">
                Behavior Policy
              </SubSectionTitle>
              <Typography paragraph>
                We reserve the right to refuse service to anyone exhibiting abusive or disruptive behavior that threatens staff or other patients.
              </Typography>
            </Box>
            
            <Box id="privacy">
              <SectionTitle variant="h4" component="h2">
                Privacy & Confidentiality
              </SectionTitle>
              <Typography paragraph>
                We protect your health information in compliance with:
              </Typography>
              <List disablePadding>
                <ListItem>
                  <ListItemText primary="HIPAA regulations" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="State privacy laws" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Our Privacy Policy" />
                </ListItem>
              </List>
              
              <SubSectionTitle variant="h5" component="h3">
                Information Use
              </SubSectionTitle>
              <Typography paragraph>
                Your health information may be used for treatment, payment, and healthcare operations as described in our Privacy Notice.
              </Typography>
            </Box>
            
            <Box id="payments">
              <SectionTitle variant="h4" component="h2">
                Payments & Billing
              </SectionTitle>
              <SubSectionTitle variant="h5" component="h3">
                Financial Responsibility
              </SubSectionTitle>
              <Typography paragraph>
                You are responsible for all charges for services received, regardless of insurance coverage.
              </Typography>
              
              <SubSectionTitle variant="h5" component="h3">
                Insurance
              </SubSectionTitle>
              <Typography paragraph>
                While we bill insurance as a courtesy, you are responsible for:
              </Typography>
              <List disablePadding>
                <ListItem>
                  <ListItemText primary="Providing accurate insurance information" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Understanding your policy benefits" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Any deductibles or co-payments" />
                </ListItem>
              </List>
              
              <NoticeBox>
                <Typography>
                  <strong>Financial Assistance:</strong> We offer financial aid programs for qualifying patients. Contact our billing department for details.
                </Typography>
              </NoticeBox>
            </Box>
            
            <Box id="liability">
              <SectionTitle variant="h4" component="h2">
                Liability
              </SectionTitle>
              <SubSectionTitle variant="h5" component="h3">
                Limitation of Liability
              </SubSectionTitle>
              <Typography paragraph>
                To the extent permitted by law, Healing Hands Hospital shall not be liable for:
              </Typography>
              <List disablePadding>
                <ListItem>
                  <ListItemText primary="Indirect or consequential damages" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Acts of third parties" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Circumstances beyond our control" />
                </ListItem>
              </List>
              
              <SubSectionTitle variant="h5" component="h3">
                Indemnification
              </SubSectionTitle>
              <Typography paragraph>
                You agree to indemnify us against any claims arising from your violation of these terms.
              </Typography>
            </Box>
            
            <Divider sx={{ my: 4 }} />
            
            <UpdateDate variant="body2">
              Effective: January 1, 2023 | Last Updated: June 15, 2023
            </UpdateDate>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
}

export default TermsAndConditions;