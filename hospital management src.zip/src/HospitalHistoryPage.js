import React from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardMedia, 
  CardContent, 
  Divider,
  useMediaQuery
} from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';

// Define theme with colors from original CSS
const theme = createTheme({
  palette: {
    primary: {
      main: '#2a5c8d',
      light: '#4b8bb9',
    },
    secondary: {
      main: '#e63946',
    },
    background: {
      default: '#f8f9fa',
      paper: '#ffffff',
    },
    text: {
      primary: '#333',
      light: '#ffffff',
    },
    dark: {
      main: '#1d3557',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h1: {
      fontWeight: 700,
      fontSize: '3.5rem',
      textShadow: '2px 2px 4px rgba(0,0,0,0.5)',
      '@media (max-width:768px)': {
        fontSize: '2.2rem',
      },
    },
    h2: {
      fontSize: '2.5rem',
      color: '#1d3557',
      fontWeight: 700,
    },
    h3: {
      fontSize: '1.3rem',
      fontWeight: 500,
    },
    h4: {
      fontSize: '1.8rem',
      color: '#2a5c8d',
      fontWeight: 700,
      marginBottom: '1rem',
    },
    body1: {
      lineHeight: 1.7,
    },
    quote: {
      fontSize: '1.8rem',
      fontStyle: 'italic',
      lineHeight: 1.6,
    },
  },
});

// Hero section component
const Hero = () => {
  return (
    <Box
      sx={{
        backgroundImage: 'linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url("https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        height: { xs: '50vh', md: '60vh' },
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        color: 'white',
        position: 'relative',
      }}
    >
      <Box sx={{ maxWidth: 800, padding: 2 }}>
        <Typography variant="h1" gutterBottom>
          Our History
        </Typography>
        <Typography variant="body1" sx={{ fontSize: { xs: '1.1rem', md: '1.3rem' }, mb: 2 }}>
          A legacy of healing and innovation since 1985
        </Typography>
      </Box>
    </Box>
  );
};

// Section title component
const SectionTitle = ({ title }) => {
  return (
    <Box sx={{ textAlign: 'center', mb: 5, position: 'relative' }}>
      <Typography
        variant="h2"
        component="h2"
        sx={{
          display: 'inline-block',
          pb: 1,
          position: 'relative',
          '&:after': {
            content: '""',
            position: 'absolute',
            width: '80px',
            height: '4px',
            backgroundColor: 'secondary.main',
            bottom: 0,
            left: '50%',
            transform: 'translateX(-50%)',
          },
        }}
      >
        {title}
      </Typography>
    </Box>
  );
};

// Decade Card component
const DecadeCard = ({ decade, title, description, image }) => {
  return (
    <Card
      sx={{
        borderRadius: '10px',
        overflow: 'hidden',
        boxShadow: '0 10px 30px rgba(0,0,0,0.1)',
        transition: 'transform 0.3s ease, box-shadow 0.3s ease',
        '&:hover': {
          transform: 'translateY(-10px)',
          boxShadow: '0 15px 35px rgba(0,0,0,0.15)',
        },
      }}
    >
      <Box
        sx={{
          height: '200px',
          overflow: 'hidden',
          '&:hover img': {
            transform: 'scale(1.1)',
          },
        }}
      >
        <CardMedia
          component="img"
          height="200"
          image={image}
          alt={decade}
          sx={{ transition: 'transform 0.5s ease' }}
        />
      </Box>
      <CardContent sx={{ padding: 3 }}>
        <Typography variant="h4" component="div">
          {decade}
        </Typography>
        <Typography variant="h3" color="text.primary" gutterBottom>
          {title}
        </Typography>
        <Typography variant="body1">
          {description}
        </Typography>
      </CardContent>
    </Card>
  );
};

// Founder Card component
const FounderCard = ({ name, title, description, image }) => {
  return (
    <Card sx={{ borderRadius: '10px', overflow: 'hidden', boxShadow: '0 5px 20px rgba(0,0,0,0.1)', textAlign: 'center' }}>
      <Box sx={{ height: '300px', overflow: 'hidden' }}>
        <CardMedia
          component="img"
          height="300"
          image={image}
          alt={name}
          sx={{ width: '100%', height: '100%', objectFit: 'cover' }}
        />
      </Box>
      <CardContent sx={{ padding: 3 }}>
        <Typography variant="h3" color="text.primary" gutterBottom>
          {name}
        </Typography>
        <Typography sx={{ color: 'primary.main', fontStyle: 'italic', mb: 1 }}>
          {title}
        </Typography>
        <Typography variant="body1">
          {description}
        </Typography>
      </CardContent>
    </Card>
  );
};

// Milestone Item component
const MilestoneItem = ({ number, text }) => {
  return (
    <Box sx={{ textAlign: 'center', padding: 2 }}>
      <Typography sx={{ fontSize: '3rem', fontWeight: 700, color: 'secondary.main', mb: 1 }}>
        {number}
      </Typography>
      <Typography sx={{ fontSize: '1.1rem', color: 'text.light' }}>
        {text}
      </Typography>
    </Box>
  );
};

// Gallery Item component
const GalleryItem = ({ image, caption }) => {
  return (
    <Box
      sx={{
        height: '250px',
        overflow: 'hidden',
        borderRadius: '8px',
        position: 'relative',
        '&:hover img': {
          transform: 'scale(1.1)',
        },
        '&:hover .caption': {
          transform: 'translateY(0)',
        },
      }}
    >
      <img
        src={image}
        alt={caption}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          transition: 'transform 0.5s ease',
        }}
      />
      <Box
        className="caption"
        sx={{
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: 'rgba(0,0,0,0.7)',
          color: 'white',
          padding: 2,
          transform: 'translateY(100%)',
          transition: 'transform 0.3s ease',
        }}
      >
        {caption}
      </Box>
    </Box>
  );
};

// Main App Component
const HospitalHistoryPage = () => {
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isTablet = useMediaQuery(theme.breakpoints.down('md'));

  return (
    <ThemeProvider theme={theme}>
      <Box sx={{ backgroundColor: 'background.default' }}>
        {/* Hero Section */}
        <Hero />
        
        <Container>
          {/* Journey Section */}
          <Box sx={{ py: { xs: 3, md: 5 } }}>
            <SectionTitle title="Our Journey Through Time" />
            
            <Box sx={{ maxWidth: 800, margin: '0 auto 4rem', textAlign: 'center' }}>
              <Typography variant="body1" sx={{ fontSize: '1.1rem' }}>
                From our humble beginnings as a small community hospital to becoming a regional healthcare leader, Healing Hands has always been driven by our commitment to exceptional patient care and medical innovation. Our history is written in the lives we've touched and the communities we've served.
              </Typography>
            </Box>
            
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6} md={4}>
                <DecadeCard
                  decade="1980s"
                  title="The Foundation Years"
                  description="Founded in 1985 by Dr. Robert Henderson and Dr. Margaret Williams, Healing Hands began as a 20-bed facility with just three physicians. Our first year saw 1,200 patient visits."
                  image="https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <DecadeCard
                  decade="1990s"
                  title="Expansion & Specialization"
                  description="The 1990s saw our first major expansion to 150 beds and the establishment of specialized units in cardiology, pediatrics, and oncology. We introduced the region's first MRI machine in 1997."
                  image="https://images.unsplash.com/photo-1581595219315-a187dd40c322?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <DecadeCard
                  decade="2000s"
                  title="A New Century of Care"
                  description="In 2005, we moved to our current 500-bed facility. This decade also saw us achieve JCI accreditation and establish our research institute focusing on cardiovascular diseases."
                  image="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyPk_rbgJDtFKHLQW0ZoJRM0WF6PStGwLPJw&s"
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <DecadeCard
                  decade="2010s"
                  title="Innovation & Recognition"
                  description="We opened the Henderson-Williams Cancer Center in 2015 and were ranked among the top 50 hospitals in the nation for cardiac care. Our telemedicine program launched in 2018."
                  image="https://images.unsplash.com/photo-1579684453423-f84349ef60b0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <DecadeCard
                  decade="2020s"
                  title="Leading Through Challenge"
                  description="During the pandemic, we served as a regional COVID-19 center while maintaining all other services. In 2023, we completed our robotic surgery suite expansion."
                  image="https://images.unsplash.com/photo-1581595219315-a187dd40c322?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
                />
              </Grid>
            </Grid>
          </Box>
          
          {/* Founders Section */}
          <Box
            sx={{
              py: { xs: 3, md: 5 },
              backgroundColor: 'background.paper',
              position: 'relative',
              overflow: 'hidden',
              '&:before': {
                content: '""',
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                background: 'url("https://images.unsplash.com/photo-1576091160399-112ba822d033?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80")',
                backgroundSize: 'cover',
                opacity: 0.1,
              },
            }}
          >
            <SectionTitle title="Our Founders" />
            
            <Grid container spacing={4}>
              <Grid item xs={12} md={6}>
                <FounderCard
                  name="Dr. RAMANA"
                  title="Cardiologist & Co-Founder"
                  description="A visionary in cardiac care, Dr. Henderson (1935-2012) established our hospital's reputation for cardiovascular excellence. His pioneering techniques in minimally invasive surgery are still used today."
                  image="https://static.vecteezy.com/system/resources/thumbnails/026/375/249/small_2x/ai-generative-portrait-of-confident-male-doctor-in-white-coat-and-stethoscope-standing-with-arms-crossed-and-looking-at-camera-photo.jpg"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <FounderCard
                  name="Dr. Thyagaraj"
                  title="Pediatrician & Co-Founder"
                  description="Dr. Williams (1940-2018) revolutionized pediatric care in our region. She established our child life program and the first neonatal intensive care unit outside the state capital."
                  image="https://static.vecteezy.com/system/resources/previews/051/355/680/non_2x/portrait-of-smiling-friendly-doctor-posing-wearing-white-coat-isolated-on-blue-background-photo.jpg"
                />
              </Grid>
            </Grid>
          </Box>
          
          {/* Milestones Section */}
          <Box sx={{ py: { xs: 3, md: 5 }, backgroundColor: 'dark.main', color: 'text.light' }}>
            <SectionTitle title="By The Numbers" />
            
            <Grid container>
              <Grid item xs={12} sm={6} md={3}>
                <MilestoneItem number="35+" text="Years Serving Our Community" />
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <MilestoneItem number="1,200+" text="Healthcare Professionals" />
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <MilestoneItem number="500+" text="Patient Beds" />
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <MilestoneItem number="1M+" text="Lives Touched" />
              </Grid>
            </Grid>
          </Box>
          
          {/* Gallery Section */}
          <Box sx={{ py: { xs: 3, md: 5 }, backgroundColor: 'background.paper' }}>
            <SectionTitle title="Through The Years" />
            
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6} md={4}>
                <GalleryItem
                  image="https://media.gettyimages.com/id/1047922950/photo/officer-shot-and-killed-in-line-of-duty-20-june-1958-thomas-scebbi-raymon-espinosa-james.jpg?s=612x612&w=gi&k=20&c=wBZcYlpG9_6P7dE6D6iGmQX04Z3I0ktdbK8kYM0ab8g="
                  caption="Original 20-bed facility (1985)"
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <GalleryItem
                  image="https://images.unsplash.com/photo-1579684385127-1ef15d508118?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
                  caption="First expansion (1992)"
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <GalleryItem
                  image="https://images.unsplash.com/photo-1581595219315-a187dd40c322?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
                  caption="New campus opening (2005)"
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <GalleryItem
                  image="https://images.unsplash.com/photo-1579684453423-f84349ef60b0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
                  caption="Cancer center opening (2015)"
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <GalleryItem
                  image="https://images.unsplash.com/photo-1581595219315-a187dd40c322?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
                  caption="Robotic surgery suite (2023)"
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <GalleryItem
                  image="https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
                  caption="Our team today"
                />
              </Grid>
            </Grid>
          </Box>
        </Container>
        
        {/* Quote Section */}
        <Box
          sx={{
            backgroundImage: 'linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url("https://images.unsplash.com/photo-1579684453423-f84349ef60b0?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundAttachment: 'fixed',
            color: 'white',
            textAlign: 'center',
            padding: { xs: '4rem 2rem', md: '8rem 2rem' },
          }}
        >
          <Container>
            <Box sx={{ maxWidth: 800, margin: '0 auto' }}>
              <Typography variant="quote">
                "We didn't set out to build just a hospital, but a healing community where science and compassion work hand in hand."
              </Typography>
              <Typography sx={{ mt: 2, fontWeight: 700, fontSize: '1.2rem' }}>
                — Dr. RAMANA, Co-Founder
              </Typography>
            </Box>
          </Container>
        </Box>
      </Box>
    </ThemeProvider>
  );
};

export default HospitalHistoryPage;