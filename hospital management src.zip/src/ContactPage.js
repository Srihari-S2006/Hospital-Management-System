import React from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Container,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
  useTheme
} from '@mui/material';
import {
  Call,
  Email,
  LocationOn,
} from '@mui/icons-material';

function ContactPage() {
  const theme = useTheme();

  const headerStyles = {
    background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.dark})`,
    color: 'white',
    padding: '2rem 0',
    textAlign: 'center',
    marginBottom: '2rem',
  };

  const contactCard = {
    height: '100%',
    transition: 'transform 0.3s ease',
    '&:hover': {
      transform: 'translateY(-5px)',
    },
    backgroundColor: theme.palette.grey[100],
  };

  const departmentCard = {
    borderLeft: `4px solid ${theme.palette.primary.main}`,
    marginBottom: theme.spacing(2),
    padding: theme.spacing(2),
  };

  const emergencyBanner = {
    backgroundColor: theme.palette.error.main,
    color: 'white',
    padding: theme.spacing(3),
    borderRadius: theme.shape.borderRadius,
    margin: `${theme.spacing(4)} 0`,
    textAlign: 'center',
  };

  const iconStyle = {
    fontSize: '2rem',
    color: theme.palette.primary.main,
    marginBottom: theme.spacing(1),
  };

  return (
    <Box>
      {/* Header */}
      <Box sx={headerStyles}>
        <Container>
          <Typography variant="h3" component="h1" gutterBottom>
            Contact Healing Hands Hospital
          </Typography>
          <Typography variant="h6">
            We're here to help and answer any questions you may have
          </Typography>
        </Container>
      </Box>

      <Container maxWidth="lg" sx={{ mb: 8 }}>
        {/* Emergency Banner */}
        <Paper sx={emergencyBanner} elevation={3}>
          <Typography variant="h5" gutterBottom>
            Emergency Services
          </Typography>
          <Typography variant="body1">
            For immediate medical attention, please call:
          </Typography>
          <Typography variant="h4" sx={{ my: 2 }}>
            <Call /> (555) 911-9111
          </Typography>
          <Typography variant="body1">
            Our Emergency Department is open 24/7, 365 days a year
          </Typography>
        </Paper>

        {/* How to Reach Us */}
        <Paper sx={{ p: 3, mb: 4 }} elevation={2}>
          <Typography variant="h4" color="primary" gutterBottom>
            How to Reach Us
          </Typography>
          <Grid container spacing={3}>
            <Grid item xs={12} md={4}>
              <Card sx={contactCard} elevation={3}>
                <CardContent>
                  <LocationOn sx={iconStyle} />
                  <Typography variant="h6" gutterBottom>
                    Main Hospital
                  </Typography>
                  <Typography variant="body1">
                    123 Wellness Boulevard<br />
                    Medicity, MC 12345<br />
                    United States
                  </Typography>
                  <Typography variant="body1" sx={{ mt: 2 }}>
                    <strong>Parking:</strong> Free parking available in front of the main entrance and in the underground garage.
                  </Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={4}>
              <Card sx={contactCard} elevation={3}>
                <CardContent>
                  <Call sx={iconStyle} />
                  <Typography variant="h6" gutterBottom>
                    Phone Contacts
                  </Typography>
                  <Typography variant="body1">
                    <strong>Main Switchboard:</strong> (555) 123-4567<br />
                    <strong>Appointments:</strong> (555) 123-4568<br />
                    <strong>Billing:</strong> (555) 123-4569<br />
                    <strong>Pharmacy:</strong> (555) 123-4570
                  </Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={4}>
              <Card sx={contactCard} elevation={3}>
                <CardContent>
                  <Email sx={iconStyle} />
                  <Typography variant="h6" gutterBottom>
                    Email
                  </Typography>
                  <Typography variant="body1">
                    <strong>General Inquiries:</strong> info@healinghandshospital.com<br />
                    <strong>Patient Relations:</strong> patientrelations@healinghandshospital.com<br />
                    <strong>Medical Records:</strong> records@healinghandshospital.com<br />
                    <strong>Career Opportunities:</strong> hr@healinghandshospital.com
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Paper>

        {/* Map */}
        <Box sx={{ height: 400, mb: 4, borderRadius: 1, overflow: 'hidden' }}>
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.215209132834!2d-73.98784492423911!3d40.74844097138996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDDCsDQ0JzU0LjQiTiA3M8KwNTknMTkuNyJX!5e0!3m2!1sen!2sus!4v1620000000000!5m2!1sen!2sus" 
            width="100%" 
            height="100%" 
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            title="Hospital Location"
          />
        </Box>

        {/* Contact Form */}
        <Paper sx={{ p: 3, mb: 4 }} elevation={2}>
          <Typography variant="h4" color="primary" gutterBottom>
            Contact Form
          </Typography>
          <Typography variant="body1" paragraph>
            Have questions or need more information? Send us a message and we'll respond as soon as possible.
          </Typography>
          
          <Box component="form" noValidate sx={{ mt: 3 }}>
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  id="name"
                  label="Full Name"
                  name="name"
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  id="email"
                  label="Email Address"
                  name="email"
                  type="email"
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  id="phone"
                  label="Phone Number"
                  name="phone"
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth variant="outlined">
                  <InputLabel id="subject-label">Subject</InputLabel>
                  <Select
                    labelId="subject-label"
                    id="subject"
                    label="Subject"
                    defaultValue=""
                  >
                    <MenuItem value=""><em>Select a subject</em></MenuItem>
                    <MenuItem value="appointment">Appointment Request</MenuItem>
                    <MenuItem value="billing">Billing Inquiry</MenuItem>
                    <MenuItem value="feedback">Feedback/Compliment</MenuItem>
                    <MenuItem value="complaint">Complaint</MenuItem>
                    <MenuItem value="medical-records">Medical Records</MenuItem>
                    <MenuItem value="general">General Inquiry</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="message"
                  label="Your Message"
                  name="message"
                  multiline
                  rows={6}
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  size="large"
                >
                  Send Message
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Paper>

        {/* Visiting Hours */}
        <Paper sx={{ p: 3, mb: 4 }} elevation={2}>
          <Typography variant="h4" color="primary" gutterBottom>
            Visiting Hours
          </Typography>
          <Typography variant="body1" paragraph>
            We welcome visitors during the following hours. Please check with the nursing station for any special restrictions.
          </Typography>
          
          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }}>
              <TableHead>
                <TableRow sx={{ backgroundColor: theme.palette.grey[100] }}>
                  <TableCell><Typography variant="subtitle1">Department</Typography></TableCell>
                  <TableCell><Typography variant="subtitle1">Hours</Typography></TableCell>
                  <TableCell><Typography variant="subtitle1">Notes</Typography></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow>
                  <TableCell>General Wards</TableCell>
                  <TableCell>10:00 AM - 8:00 PM</TableCell>
                  <TableCell>2 visitors at a time</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Intensive Care Unit</TableCell>
                  <TableCell>11:00 AM - 1:00 PM<br />5:00 PM - 7:00 PM</TableCell>
                  <TableCell>Immediate family only, 1 visitor at a time</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Maternity</TableCell>
                  <TableCell>9:00 AM - 9:00 PM</TableCell>
                  <TableCell>Partners have 24-hour access</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Pediatrics</TableCell>
                  <TableCell>10:00 AM - 8:00 PM</TableCell>
                  <TableCell>Parents may stay overnight</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Emergency Department</TableCell>
                  <TableCell>Limited visiting</TableCell>
                  <TableCell>At staff discretion based on patient condition</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>

        {/* Department Direct Contacts */}
        <Paper sx={{ p: 3, mb: 4 }} elevation={2}>
          <Typography variant="h4" color="primary" gutterBottom>
            Department Direct Contacts
          </Typography>
          <Typography variant="body1" paragraph>
            For specific inquiries, you may contact these departments directly:
          </Typography>
          
          <Grid container spacing={3}>
            {[
              { name: 'Cardiology', phone: '(555) 123-4610', email: 'cardiology@healinghandshospital.com' },
              { name: 'Oncology', phone: '(555) 123-4611', email: 'oncology@healinghandshospital.com' },
              { name: 'Orthopedics', phone: '(555) 123-4612', email: 'orthopedics@healinghandshospital.com' },
              { name: 'Neurology', phone: '(555) 123-4613', email: 'neurology@healinghandshospital.com' },
              { name: 'Pediatrics', phone: '(555) 123-4614', email: 'pediatrics@healinghandshospital.com' },
              { name: 'Maternity', phone: '(555) 123-4615', email: 'maternity@healinghandshospital.com' }
            ].map((dept, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <Paper sx={departmentCard} elevation={1}>
                  <Typography variant="h6" gutterBottom>
                    {dept.name}
                  </Typography>
                  <Typography variant="body2">
                    <Call fontSize="small" /> {dept.phone}
                  </Typography>
                  <Typography variant="body2">
                    <Email fontSize="small" /> {dept.email}
                  </Typography>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </Paper>

        {/* Patient Feedback */}
        <Paper sx={{ p: 3, mb: 4 }} elevation={2}>
          <Typography variant="h4" color="primary" gutterBottom>
            Patient Feedback
          </Typography>
          <Typography variant="body1" paragraph>
            Your feedback helps us improve our services. We welcome both compliments and concerns about your experience at Healing Hands Hospital.
          </Typography>
          <Typography variant="body1">
            <strong>Patient Relations Office:</strong> Open Monday-Friday, 8:00 AM - 5:00 PM
          </Typography>
          <Typography variant="body1" sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Call fontSize="small" /> (555) 123-4590 | <Email fontSize="small" /> patientrelations@healinghandshospital.com
          </Typography>
        </Paper>
      </Container>
    </Box>
  );
}

export default ContactPage;