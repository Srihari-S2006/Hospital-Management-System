import React from 'react';
import { 
  Box, 
  Typography, 
  Grid, 
  Link, 
  Divider, 
  IconButton, 
  useTheme,
  Container 
} from '@mui/material';
import { 
  Apple as AppleIcon, 
  Android as AndroidIcon,
  Facebook as FacebookIcon,
  Twitter as TwitterIcon,
  Instagram as InstagramIcon,
  LinkedIn as LinkedInIcon
} from '@mui/icons-material';
import { Link as RouterLink } from 'react-router-dom';

const Footer = () => {
  const theme = useTheme();
  
  return (
    <Box sx={{ 
      backgroundColor: theme.palette.grey[900],
      color: theme.palette.common.white,
      padding: { xs: 3, md: 6 },
      mt: 8
    }}>
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          {/* About Us Column */}
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="h6" sx={{ fontWeight: 'bold', mb: 2 }}>
              ABOUT US
            </Typography>
            <Typography variant="body2" sx={{ mb: 2 }}>
              Overview
            </Typography>
            
            <Typography variant="h6" sx={{ fontWeight: 'bold', mt: 3, mb: 2 }}>
              Download Our App
            </Typography>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <IconButton 
                color="inherit" 
                sx={{ 
                  backgroundColor: theme.palette.grey[800],
                  borderRadius: 1,
                  padding: '6px 12px'
                }}
              >
                <AndroidIcon sx={{ mr: 1 }} />
                <Typography variant="caption">Google Play</Typography>
              </IconButton>
              <IconButton 
                color="inherit" 
                sx={{ 
                  backgroundColor: theme.palette.grey[800],
                  borderRadius: 1,
                  padding: '6px 12px'
                }}
              >
                <AppleIcon sx={{ mr: 1 }} />
                <Typography variant="caption">App Store</Typography>
              </IconButton>
            </Box>
          </Grid>

          {/* Specialities Column */}
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="h6" sx={{ fontWeight: 'bold', mb: 2 }}>
              SPECIALITIES
            </Typography>
            {[
              'Emergency Care',
              'Anaserhesiology',
              'Cardiology',
              'Critical Care',
              'Dentistry',
              'Dermatology & Cosmetology',
              'Diabetiology & Endocrinology'
            ].map((item, index) => (
              <Typography key={index} variant="body2" sx={{ mb: 1 }}>
                {item}
              </Typography>
            ))}
          </Grid>

          {/* Locations Column */}
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="h6" sx={{ fontWeight: 'bold', mb: 2 }}>
              LOCATIONS
            </Typography>
            {[
              'Chennai - Tambaram',
              'T. Nagar',
              'Kipsuk',
              'Poonamallee',
              'Ambattur',
              'Anna Nagar',
              'Selapur'
            ].map((item, index) => (
              <Typography key={index} variant="body2" sx={{ mb: 1 }}>
                {item}
              </Typography>
            ))}
          </Grid>

          {/* Quick Links & Contact Column */}
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="h6" sx={{ fontWeight: 'bold', mb: 2 }}>
              QUICK LINKS
            </Typography>
            {[
              { label: 'Home', path: '/' },
              { label: 'Careers', path: '/careers' },
              { label: 'Privacy Policy', path: '/privacy-policy' },
              { label: 'Request an Appointment', path: '/appointment' },
              { label: 'Search a Doctor', path: '/' },
              { label: 'Terms and Conditions', path: '/terms-and-conditions' }
            ].map((item, index) => (
              <Typography key={index} variant="body2" sx={{ mb: 1 }}>
                <Link 
                  component={RouterLink} 
                  to={item.path} 
                  color="inherit" 
                  underline="hover"
                >
                  {item.label}
                </Link>
              </Typography>
            ))}

            <Typography variant="h6" sx={{ fontWeight: 'bold', mt: 3, mb: 2 }}>
              CONTACT US
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              Be Well Hospitals Private Limited
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              No. 54, Vijayaraghava Road, T.Nagar, Chennai - 600 017, Tamil Nadu, India.
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              Emergency/ Appointment: +91 9698 300 300
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              <Link href="https://www.bewellhospitals.in" color="inherit" underline="hover">
                www.bewellhospitals.in
              </Link>
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              Email: <Link href="mailto:ask@bewellhospitals.in" color="inherit" underline="hover">
                ask@bewellhospitals.in
              </Link>
            </Typography>

            <Typography variant="body2" sx={{ mt: 2, mb: 1 }}>
              Follow us on
            </Typography>
            <Box sx={{ display: 'flex', gap: 1 }}>
              {[FacebookIcon, TwitterIcon, InstagramIcon, LinkedInIcon].map((Icon, index) => (
                <IconButton key={index} color="inherit" size="small">
                  <Icon />
                </IconButton>
              ))}
            </Box>
          </Grid>
        </Grid>

        <Divider sx={{ my: 4, backgroundColor: theme.palette.grey[700] }} />

        <Typography variant="body2" align="center">
          © 2025 Hospital Management. All rights reserved.
        </Typography>
      </Container>
    </Box>
  );
};

export default Footer;
