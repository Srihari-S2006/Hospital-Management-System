import React from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Menu,
  MenuItem,
  Button,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Box,
  useTheme,
  useMediaQuery,
  InputBase,
  Paper,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import { Link } from "react-router-dom"; // ✅ Import Link from react-router-dom

const Navbar = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  const [anchorElApp, setAnchorElApp] = React.useState(null);
  const [anchorElHosp, setAnchorElHosp] = React.useState(null);
  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const [searchQuery, setSearchQuery] = React.useState("");

  const handleMenuOpen = (event, setter) => setter(event.currentTarget);
  const handleMenuClose = (setter) => setter(null);

  const navLinkStyle = {
    color: "white",
    textTransform: "none",
    fontWeight: 500,
    fontSize: "1rem",
    marginRight: "16px",
  };

  const appointmentItems = [
    { text: "Book Appointment", to: "/appointment" },
    { text: "View Appointment", to: "/view-appointment" },
    { text: "Reschedule/Cancel", to: "/manage-appointment" },
  ];

  const hospitalItems = [
    { text: "History", to: "/hospital-history" },
    { text: "About Us", to: "/about-us" },
    { text: "Contact Us", to: "/contact" },
    { text: "FAQs", to: "/faq" },
  ];

  const drawerList = (
    <Box sx={{ width: 250 }} role="presentation" onClick={() => setDrawerOpen(false)}>
      <List>
        <ListItem button component={Link} to="/">
          <ListItemText primary="Home" />
        </ListItem>
        <ListItem button component={Link} to="/specialties">
          <ListItemText primary="Our Specialties" />
        </ListItem>
        <ListItem>
          <ListItemText primary="Appointment" />
        </ListItem>
        {appointmentItems.map((item) => (
          <ListItem button key={item.text} component={Link} to={item.to} sx={{ pl: 4 }}>
            <ListItemText primary={item.text} />
          </ListItem>
        ))}
        <ListItem>
          <ListItemText primary="Hospital" />
        </ListItem>
        {hospitalItems.map((item) => (
          <ListItem button key={item.text} component={Link} to={item.to} sx={{ pl: 4 }}>
            <ListItemText primary={item.text} />
          </ListItem>
        ))}
      </List>
    </Box>
  );

  return (
    <>
      <AppBar
        position="static"
        sx={{
          backgroundColor: "#0D6EFD",
          boxShadow: "0px 2px 10px rgba(0,0,0,0.1)",
        }}
      >
        <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Typography variant="h6" sx={{ fontWeight: "bold", color: "white", mr: 2 }}>
              Healing Hands
            </Typography>
            {!isMobile && (
              <>
                <Button component={Link} to="/" sx={navLinkStyle}>
                  Home
                </Button>
                <Button component={Link} to="/specialties" sx={navLinkStyle}>
                  Our Specialties
                </Button>
                <Button
                  onClick={(e) => handleMenuOpen(e, setAnchorElApp)}
                  sx={navLinkStyle}
                  endIcon={<ArrowDropDownIcon />}
                >
                  Appointment
                </Button>
                <Menu
                  anchorEl={anchorElApp}
                  open={Boolean(anchorElApp)}
                  onClose={() => handleMenuClose(setAnchorElApp)}
                >
                  {appointmentItems.map((item) => (
                    <MenuItem key={item.text} component={Link} to={item.to}>
                      {item.text}
                    </MenuItem>
                  ))}
                </Menu>
                <Button
                  onClick={(e) => handleMenuOpen(e, setAnchorElHosp)}
                  sx={navLinkStyle}
                  endIcon={<ArrowDropDownIcon />}
                >
                  Hospital
                </Button>
                <Menu
                  anchorEl={anchorElHosp}
                  open={Boolean(anchorElHosp)}
                  onClose={() => handleMenuClose(setAnchorElHosp)}
                >
                  {hospitalItems.map((item) => (
                    <MenuItem key={item.text} component={Link} to={item.to}>
                      {item.text}
                    </MenuItem>
                  ))}
                </Menu>
              </>
            )}
          </Box>

          {!isMobile ? (
            <Paper
              component="form"
              sx={{
                display: "flex",
                borderRadius: "10px",
                overflow: "hidden",
                bgcolor: "#212529",
              }}
              onSubmit={(e) => {
                e.preventDefault();
                console.log("Search:", searchQuery);
              }}
            >
              <InputBase
                placeholder="Search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                sx={{
                  color: "white",
                  px: 2,
                  width: "200px",
                }}
              />
              <Button
                type="submit"
                sx={{
                  bgcolor: "white",
                  color: "black",
                  px: 2,
                  borderRadius: 0,
                  "&:hover": {
                    bgcolor: "#f0f0f0",
                  },
                }}
              >
                Search
              </Button>
            </Paper>
          ) : (
            <IconButton color="inherit" onClick={() => setDrawerOpen(true)}>
              <MenuIcon />
            </IconButton>
          )}
        </Toolbar>
      </AppBar>
      <Drawer anchor="right" open={drawerOpen} onClose={() => setDrawerOpen(false)}>
        {drawerList}
      </Drawer>
    </>
  );
};

export default Navbar;
