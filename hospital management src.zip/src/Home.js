import React from 'react';
import { Grid, Card, CardMedia, CardContent, Typography, Box,Button,Avatar,useTheme, useMediaQuery , Container } from '@mui/material';






const specialties = [
  {
    title: "Nephrology",
    image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/nephrology.webp",
  },
  {
    title: "Occupational Medicine",
    image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/occupational_medicine.webp",
  },
  {
    title: "Ophthalmology",
    image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/ophthalmology.webp",
  },
  {
    title: "Pulmonology",
    image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/pulmonology.webp",
  },
  {
    title: "Psychiatric Medicine ",
    image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/psychiatric_medicine_counselling.webp",
  },
  {
    title: "Plastic Surgery ",
    image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/plastic_surgery_cosmetic_surgery.webp",
  },
  {
    title: "Rehabilitation Medicine",
    image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/mehabilitation_medicine_physiotherapy.webp",
  },
  {
    title: "Rheumatology",
    image: "https://deepamhospitals.com/public/assets/img/deepam/speciality/rheumatology.webp",
  },
];

const doctors = [
  {
    name: 'Dr. Muthu Veeramani',
    title: 'Director & Senior Consultant',
    specialty: 'Renal Science & Transplantation',
    image: 'https://simshospitals.com/wp-content/uploads/2021/09/Dr.-Muthu-Veeramani-Urologist-Chennai.png'
  },
  {
    name: 'Dr. R Krishnamoorthy',
    title: 'Joint Director and Senior Consultant',
    specialty: 'Plastic Surgery',
    image: 'https://simshospitals.com/wp-content/uploads/2021/09/Dr.-R-Krishnamoorthy-Plastic-Surgeon-Chennai.png'
  },
  {
    name: 'Dr. Vivekanandan Shanmugam',
    title: 'Lead Surgeon',
    specialty: 'Liver Transplantation',
    image: 'https://simshospitals.com/wp-content/uploads/2021/10/Dr.-Vivekanandan-Shanmugam-Liver-Transplant-Surgeon-Chennai.png'
  },
  {
    name: 'Dr. K R Suresh Bapu',
    title: 'Director & Senior Consultant',
    specialty: 'Institute of Neuroscience',
    image: 'https://simshospitals.com/wp-content/uploads/2019/07/Dr.-K-R-Suresh-Bapu-Neurosurgeon-Chennai.png'
  },
  {
    name: 'Dr. V V Bashi',
    title: 'Director & Senior Consultant',
    specialty: 'Cardiac & Advanced Aortic Diseases',
    image: 'https://simshospitals.com/wp-content/uploads/2021/09/Dr.-V-V-Bashi-Cardiac-Surgeon-Chennai.png'
  },
  {
    name: 'Dr. K Sridhar',
    title: 'Director & Senior Consultant',
    specialty: 'Craniofacial and Plastic Surgery',
    image: 'https://simshospitals.com/wp-content/uploads/2021/10/Dr.-K-Sridhar-Plastic-Surgeon-Chennai.png'
  },
  {
    name: 'Dr. B S Ramakrishna',
    title: 'Director & Senior Consultant',
    specialty: 'Gastroenterology',
    image: 'https://simshospitals.com/wp-content/uploads/2021/09/Dr.-B-S-Ramakrishna-Medical-Gastroenterologist-Chennai.png'
  },
  {
    name: 'Dr. C Vijay Bose',
    title: 'Joint Director & Senior Consultant',
    specialty: 'Orthopaedic Surgeon',
    image: 'https://simshospitals.com/wp-content/uploads/2021/09/Dr.-Vijay-C-Bose-Knee-Replacement-Surgeon-Chennai.png'
  }
];
const blogArticles = [
  {
    image: 'https://simshospitals.com/homepage/blog1.png', // Replace with actual image paths
    title: "Caring for a Loved One with Alzheimer's Tips for Family Caregivers",
    description:
      "In the labyrinth of Alzheimer's, family caregivers find themselves as steadfast navigators, embracing both the challenges and the profound moments of connection that come with caring for a loved one with this condition."
  },
  {
    image: 'https://simshospitals.com/homepage/blog2.png',
    title: 'The role of physiotherapy in orthopedic recovery',
    description:
      'In the intricate dance of orthopedic recovery, physiotherapy takes center stage as a guiding partner, offering support, rehabilitation and a pathway to restored mobility. The scope of physiotherapy within orthopedics is vast...'
  },
  {
    image: 'https://simshospitals.com/homepage/blog3.png',
    title: 'Empower Your Health World Diabetes Day 2023 - Know, Prevent...',
    description:
      'In the symphony of global health initiatives, World Diabetes Day plays a crucial tune, resonating with millions to "Know, Prevent, and Control" diabetes. As health-conscious individuals, understanding the significance of...'
  }
];

const stats = [
  { value: '158000', label: 'Happy People' },
  { value: '1700', label: 'Surgery Completed' },
  { value: '10000', label: 'Expert Doctors' },
  { value: '350', label: 'Worldwide Branch' }
];
const services = [
  {
    icon: '🧪',
    title: 'Laboratory Services',
    description: 'We provide quality lab tests with accurate results.',
  },
  {
    icon: '❤️',
    title: 'Heart Disease',
    description: 'Comprehensive heart care treatments and surgery.',
  },
  {
    icon: '🦷',
    title: 'Dental Care',
    description: 'Professional dental services advanced technology.',
  },
  {
    icon: '💀',
    title: 'Body Surgery',
    description: 'Advanced surgical procedures with experienced .',
  },
  {
    icon: '🧠',
    title: 'Neurology Surgery',
    description: 'Expert care for brain and nerve-related conditions .',
  },
  {
    icon: '🧬',
    title: 'Gynecology',
    description: "Specialized care for women's health and maternity.",
  },
];




export const Home = () => {
  return (
    <Box>
      {/* Video Section */}
      <Box sx={{ textAlign: 'center', p: 4 }}>
        <Box
          component="video"
          src="https://billrothhospitals.com/wp-content/uploads/2024/04/Adhitri_Master_1080P_1.mp4"
          autoPlay
          muted
          loop
          playsInline
          sx={{
            width: "100%",
            borderRadius: "12px",
            boxShadow: 3,
            mt: 2,
          }}
        />
      </Box>

      <Box sx={{ backgroundColor: '#fef3ec', py: { xs: 6, md: 10 } }}>
      <Container maxWidth="lg">
        <Grid
          container
          spacing={4}
          alignItems="center"
          justifyContent="center"
          direction={{ xs: 'column', md: 'row' }}
        >
          {/* Left Side - Text */}
          <Grid item xs={12} md={6}>
            <Box sx={{ textAlign: 'center' }}>
              <Typography
                variant="h4"
                fontWeight="bold"
                sx={{ mb: 1 }}
              >
                You Are Unique, Your Health <br />
                Check Should Be Too!
              </Typography>

              <Typography
                variant="body1"
                color="text.secondary"
                sx={{ mt: 2, mb: 2, maxWidth: 500, mx: 'auto' }}
              >
                Healing hands ProHealth is the world’s most advanced health check,
                crafted by expert doctors and AI. Answer a few questions so we can
                design an individualized health plan for you with free doctor and
                specialist consultations included!
              </Typography>

              <Typography
                variant="h6"
                fontWeight="bold"
                sx={{ mt: 3 }}
              >
                Customise Your Unique Health Check
              </Typography>

              <Box sx={{ mt: 2 }}>
                <Button
                  variant="contained"
                  size="large"
                  sx={{
                    backgroundColor: '#000',
                    borderRadius: 999,
                    px: 4,
                    py: 1.5,
                    fontWeight: 'bold',
                    '&:hover': {
                      backgroundColor: '#333',
                    },
                  }}
                >
                  BOOK HEALTH CHECK-UP →
                </Button>
              </Box>
            </Box>
          </Grid>

          {/* Right Side - Image */}
          <Grid item xs={12} md={6}>
            <Box
              component="img"
              src="https://www.apollohospitals.com/sites/default/files/styles/prohealth_featured/public/2024-12/yoga-girl.png?h=5784954b&itok=dxuy5Bbw"
              alt="Yoga Lady"
              sx={{
                width: '100%',
                maxWidth: 500,
                display: 'block',
                mx: 'auto',
              }}
            />
          </Grid>
        </Grid>
      </Container>
    </Box>
    
      {/* Specialties Section */}
      <Box sx={{ py: 6, backgroundColor: '#fef3ec', px: 2 }}>
        <Typography
          variant="h5"
          sx={{
            fontWeight: 'bold',
            textAlign: 'center',
            mb: 4,
            display: 'inline-block',
            px: 3,
            py: 1,
            backgroundColor: '#264653',
            color: 'white',
            borderRadius: 2,
          }}
        >
          Our Specialties
        </Typography>

        <Container maxWidth="xl">
          <Grid container spacing={4} justifyContent="center">
            {specialties.map((item, index) => (
              <Grid item xs={12} sm={6} md={3} key={index}>
                <Card
                  sx={{
                    borderRadius: 3,
                    overflow: 'hidden',
                    boxShadow: 3,
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                  }}
                >
                  <CardMedia
                    component="img"
                    image={item.image}
                    alt={item.title}
                    height="180"
                    sx={{ objectFit: 'cover' }}
                  />
                  <CardContent sx={{ textAlign: 'center' }}>
                    <Typography variant="h6" fontWeight="bold">
                      {item.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Explore More
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>
      <Box sx={{ backgroundColor: '#fef3ec', py: 5 }}>
      <Container maxWidth="md">
        <Card
          sx={{
            borderRadius: 3,
            boxShadow: 4,
            overflow: 'hidden',
            textAlign: 'center',
          }}
        >
          {/* Full-width image */}
          <Box
            component="img"
            src="https://t4.ftcdn.net/jpg/09/89/40/13/240_F_989401397_M3ABwyN2Daea1sNuucReswWtYbgMCZsd.jpg"
            alt="24 Hours Service"
            sx={{
              width: '100%',
              height: { xs: 200, sm: 300, md: 350 },
              objectFit: 'cover',
            }}
          />

          {/* Content */}
          <CardContent>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              24 Hours service
            </Typography>
            <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
              Online Appointment
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Get all-time support for emergencies. We have introduced the principle of family medicine.
            </Typography>
            <Button variant="contained" sx={{ backgroundColor: '#264653' }}>
              MAKE AN APPOINTMENT
            </Button>
          </CardContent>
        </Card>
      </Container>
    </Box>


    <Box sx={{ px: 4, py: 6, backgroundColor: '#fffaf6' }}>
      <Typography variant="h6" align="center" gutterBottom>
        Meet Our Experienced Team
      </Typography>
      <Typography variant="h4" align="center" fontWeight="bold" gutterBottom>
        Our Dedicated Doctors Team
      </Typography>
      <Grid container spacing={4} justifyContent="center">
        {doctors.map((doc, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <Card elevation={3} sx={{ borderRadius: 4, textAlign: 'center', py: 3 }}>
              <Avatar
                src={doc.image}
                alt={doc.name}
                sx={{ width: 80, height: 80, margin: '0 auto', mb: 2 }}
              />
              <CardContent>
                <Typography variant="subtitle1" fontWeight="bold">
                  {doc.name}
                </Typography>
                <Typography variant="body2">{doc.title}</Typography>
                <Typography variant="body2" sx={{ mt: 0.5 }}>
                  {doc.specialty}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>

     <Box sx={{ px: 3, py: 6, bgcolor: '#fdf3ec' }}>
      <Typography
        variant="h4"
        align="center"
        fontWeight={600}
        color="text.primary"
        gutterBottom
      >
        Resources to keep you Healthy
      </Typography>
      <Typography
        variant="subtitle1"
        align="center"
        color="text.secondary"
        mb={4}
      >
        Blogs and Articles
      </Typography>

      <Box
        sx={{
          display: 'flex',
          gap: 4,
          justifyContent: 'center',
          flexWrap: 'nowrap',
          overflowX: 'auto', // Optional: horizontal scroll on small screens
        }}
      >
        {blogArticles.map((article, index) => (
          <Card
            key={index}
            sx={{
              width: 300,
              minWidth: 300,
              flexShrink: 0,
              borderRadius: 2,
              boxShadow: '0px 4px 20px rgba(0,0,0,0.05)',
              display: 'flex',
              flexDirection: 'column'
            }}
          >
            <CardMedia
              component="img"
              height="240"
              image={article.image}
              alt={article.title}
              sx={{ objectFit: 'cover' }}
            />
            <CardContent>
              <Typography
                variant="subtitle1"
                fontWeight="600"
                align="center"
                gutterBottom
              >
                {article.title}
              </Typography>
              <Typography
                variant="body2"
                color="text.secondary"
                align="center"
              >
                {article.description}
              </Typography>
            </CardContent>
          </Card>
        ))}
      </Box>
    </Box>


    <Box sx={{ bgcolor: '#fdf7f3', py: 6, px: 2 }}>
      <Grid container spacing={4} justifyContent="center">
        {stats.map((stat, index) => (
          <Grid
            item
            xs={12}
            sm={6}
            md={3}
            key={index}
            sx={{ textAlign: 'center' }}
          >
            <Typography
              variant="h4"
              fontWeight={700}
              color="text.primary"
              gutterBottom
            >
              {stat.value}
            </Typography>
            <Typography
              variant="subtitle1"
              color="text.secondary"
            >
              {stat.label}
            </Typography>
          </Grid>
        ))}
      </Grid>
    </Box>
    
    <Box sx={{ bgcolor: '#fff6f1', py: 8, px: 2 }}>
      <Typography
        variant="h4"
        align="center"
        fontWeight={700}
        sx={{ fontSize: { xs: '1.8rem', md: '2.4rem' }, mb: 4 }}
      >
        Award Winning Patient Care
      </Typography>
      <Typography
        variant="subtitle1"
        align="center"
        color="text.secondary"
        sx={{ mb: 6 }}
      >
        We provide top-notch healthcare services with experienced doctors.
      </Typography>

      <Grid container spacing={4} justifyContent="center">
        {services.map((service, index) => (
          <Grid item xs={12} sm={6} md={4} key={index}>
            <Card
              elevation={3}
              sx={{
                borderRadius: 3,
                textAlign: 'center',
                p: 3,
                height: '100%',
                bgcolor: '#ffffff',
                transition: 'transform 0.2s ease-in-out, box-shadow 0.2s',
                '&:hover': {
                  transform: 'translateY(-5px)',
                  boxShadow: 6,
                },
              }}
            >
              <CardContent>
                <Typography variant="h2" sx={{ fontSize: '3rem', mb: 2 }}>
                  {service.icon}
                </Typography>
                <Typography variant="h6" fontWeight={700} gutterBottom>
                  {service.title}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {service.description}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
    
    
     


    </Box>
  );
};

export default Home;