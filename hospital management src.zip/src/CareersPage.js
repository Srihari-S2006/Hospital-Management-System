import React from 'react';
import { 
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  Container,
  Divider,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Rating,
  Select,
  TextField,
  Typography,
  useTheme
} from '@mui/material';
import {
  CheckCircle,
  LocationOn,
  Work,
  CalendarToday,
  Favorite,
  School,
  EventAvailable,
  AccountBalance,
  Restaurant,
  ChildCare
} from '@mui/icons-material';

function CareersPage() {
  const theme = useTheme();

  const primaryBlue = '#005b9f';
  const secondaryBlue = '#0077cc';
  const lightBlue = '#e6f2ff';
  const darkBlue = '#003366';
  const accentRed = '#e63946';
  const lightGray = '#f5f5f5';

  // Mock data for job listings
  const jobListings = [
    {
      id: 1,
      title: 'Registered Nurse',
      department: 'Nursing Department',
      location: 'Chennai',
      type: 'Full-time',
      posted: 'Posted 2 days ago',
      description: "We're seeking experienced RNs to provide high-quality patient care in our busy medical-surgical unit. BSN preferred with minimum 2 years experience."
    },
    {
      id: 2,
      title: 'Medical Laboratory Technician',
      department: 'Pathology Department',
      location: 'Chennai',
      type: 'Full-time',
      posted: 'Posted 1 week ago',
      description: "Perform clinical laboratory tests to obtain data for diagnosis and treatment of disease. MLT certification required with 1+ years experience."
    },
    {
      id: 3,
      title: 'Physical Therapist',
      department: 'Rehabilitation Services',
      location: 'Trichy',
      type: 'Part-time',
      posted: 'Posted 3 days ago',
      description: "Provide physical therapy services to patients with injuries or illnesses to restore function and mobility. DPT degree and state license required."
    },
    {
      id: 4,
      title: 'IT Support Specialist',
      department: 'Information Technology',
      location: 'Chennai',
      type: 'Full-time',
      posted: 'Posted 5 days ago',
      description: "Provide technical support for hospital systems including EHR, network infrastructure, and end-user devices. Healthcare IT experience preferred."
    }
  ];

  // Benefits data
  const benefits = [
    { icon: <Favorite fontSize="large" />, title: 'Health Insurance', description: 'Comprehensive medical, dental, and vision coverage for you ' },
    { icon: <School fontSize="large" />, title: 'Continuing Education', description: 'Tuition reimbursement and professional development opp' },
    { icon: <EventAvailable fontSize="large" />, title: 'Paid Time Off', description: 'Generous vacation, sick leave, and holiday benefits' },
    { icon: <AccountBalance fontSize="large" />, title: 'Retirement Plans', description: '401(k) with employer matching contributions' },
    { icon: <Restaurant fontSize="large" />, title: 'Meal Benefits', description: 'Subsidized meals in our hospital cafeteria' },
    { icon: <ChildCare fontSize="large" />, title: 'Family Support', description: 'Childcare assistance and parental leave policies' }
  ];

  // Testimonial data
  const testimonials = [
    {
      name: 'Dr. Priya Sharma',
      position: 'Cardiologist',
      image: 'https://randomuser.me/api/portraits/women/45.jpg',
      testimony: "The collaborative environment at Healing Hands allows me to provide the best care to my patients while continuing to learn from my coll.",
      rating: 5
    },
    {
      name: 'Raj Kumar',
      position: 'Head Nurse',
      image: 'https://randomuser.me/api/portraits/men/32.jpg',
      testimony: "I've worked at several hospitals, but Healing Hands truly values its nursing staff. The leadership listens to our concerns and supports our .",
      rating: 4.5
    },
    {
      name: 'Ananya Patel',
      position: 'IT Specialist',
      image: 'https://randomuser.me/api/portraits/women/68.jpg',
      testimony: "Even as non-clinical staff, I feel my work contributes to patient care. The hospital invests in the latest technology and provides excellent .",
      rating: 5
    }
  ];

  return (
    <Box>
      {/* Hero Section */}
      <Box
        sx={{
          background: `linear-gradient(rgba(0, 91, 159, 0.8), rgba(0, 51, 102, 0.8)), url('https://images.unsplash.com/photo-1579684385127-1ef15d508118?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          color: 'white',
          py: 12,
          textAlign: 'center'
        }}
      >
        <Container>
          <Typography variant="h2" fontWeight="bold" mb={2}>
            Join Our Team
          </Typography>
          <Typography variant="h5" mb={3}>
            Be part of a healthcare institution that makes a difference every day
          </Typography>
          <Button 
            variant="contained" 
            color="inherit" 
            size="large"
            href="#open-positions"
            sx={{ mt: 2, color: primaryBlue }}
          >
            View Open Positions
          </Button>
        </Container>
      </Box>

      {/* Why Work With Us */}
      <Box py={6}>
        <Container>
          <Grid container spacing={4} alignItems="center">
            <Grid item xs={12} md={6}>
              <Typography variant="h4" mb={3}>
                Why Work at Healing Hands?
              </Typography>
              <Typography variant="body1" mb={3}>
                At Healing Hands Hospital, we believe our employees are our greatest asset. We're committed to creating an environment where medical professionals can thrive while delivering exceptional patient care.
              </Typography>
              <Box>
                {['State-of-the-art medical facilities', 'Continuous professional development', 'Collaborative work environment', 'Competitive compensation packages'].map((item, index) => (
                  <Box key={index} display="flex" alignItems="center" mb={1}>
                    <CheckCircle sx={{ color: primaryBlue, mr: 1 }} />
                    <Typography>{item}</Typography>
                  </Box>
                ))}
              </Box>
            </Grid>
            <Grid item xs={12} md={6}>
              <Box component="img" 
                src="https://images.unsplash.com/photo-1581056771107-24ca5f033842?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
                alt="Hospital Team"
                sx={{ width: '100%', borderRadius: 2 }}
              />
            </Grid>
          </Grid>
        </Container>
      </Box>

      {/* Current Openings */}
      <Box py={6} bgcolor={lightGray} id="open-positions">
        <Container>
          <Box textAlign="center" mb={5}>
            <Typography variant="h4" mb={1}>
              Current Job Openings
            </Typography>
            <Typography variant="h6">
              Explore opportunities to join our healthcare team
            </Typography>
          </Box>
          
          <Grid container spacing={3}>
            {jobListings.map(job => (
              <Grid item xs={12} md={6} key={job.id}>
                <Card 
                  sx={{ 
                    height: '100%',
                    transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-5px)',
                      boxShadow: '0 10px 20px rgba(0, 0, 0, 0.1)'
                    }
                  }}
                >
                  <CardHeader
                    title={
                      <Typography variant="h6" color={primaryBlue}>
                        {job.title}
                      </Typography>
                    }
                    subheader={
                      <Typography color={accentRed} fontWeight={500}>
                        {job.department}
                      </Typography>
                    }
                    sx={{ bgcolor: lightBlue }}
                  />
                  <CardContent>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, mb: 2 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', color: 'text.secondary' }}>
                        <LocationOn fontSize="small" sx={{ mr: 0.5 }} />
                        <Typography variant="body2">{job.location}</Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', color: 'text.secondary' }}>
                        <Work fontSize="small" sx={{ mr: 0.5 }} />
                        <Typography variant="body2">{job.type}</Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', color: 'text.secondary' }}>
                        <CalendarToday fontSize="small" sx={{ mr: 0.5 }} />
                        <Typography variant="body2">{job.posted}</Typography>
                      </Box>
                    </Box>
                    <Typography variant="body2" mb={2}>
                      {job.description}
                    </Typography>
                    <Button 
                      variant="contained" 
                      color="primary" 
                      href="#apply"
                      sx={{ bgcolor: primaryBlue }}
                    >
                      Apply Now
                    </Button>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* Benefits Section */}
      <Box py={6} bgcolor={lightBlue}>
        <Container>
          <Box textAlign="center" mb={5}>
            <Typography variant="h4" mb={1}>
              Our Employee Benefits
            </Typography>
            <Typography variant="h6">
              We take care of our team members
            </Typography>
          </Box>
          
          <Grid container spacing={3}>
            {benefits.map((benefit, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <Card sx={{ height: '100%', textAlign: 'center', p: 3, boxShadow: 3 }}>
                  <Box sx={{ color: primaryBlue, mb: 2 }}>
                    {benefit.icon}
                  </Box>
                  <Typography variant="h6" mb={1}>
                    {benefit.title}
                  </Typography>
                  <Typography variant="body2">
                    {benefit.description}
                  </Typography>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* Employee Testimonials */}
      <Box py={6}>
        <Container>
          <Box textAlign="center" mb={5}>
            <Typography variant="h4" mb={1}>
              What Our Team Says
            </Typography>
            <Typography variant="h6">
              Hear from our current employees
            </Typography>
          </Box>
          
          <Grid container spacing={3}>
            {testimonials.map((testimonial, index) => (
              <Grid item xs={12} md={4} key={index}>
                <Card sx={{ height: '100%', p: 3, boxShadow: 3 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <Box
                      component="img"
                      src={testimonial.image}
                      alt={testimonial.name}
                      sx={{
                        width: 80,
                        height: 80,
                        borderRadius: '50%',
                        objectFit: 'cover',
                        border: `3px solid ${lightBlue}`,
                        mr: 2
                      }}
                    />
                    <Box>
                      <Typography variant="h6" mb={0.5}>
                        {testimonial.name}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {testimonial.position}
                      </Typography>
                    </Box>
                  </Box>
                  <Typography variant="body2" mb={2}>
                    "{testimonial.testimony}"
                  </Typography>
                  <Rating value={testimonial.rating} precision={0.5} readOnly />
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* Application Form */}
      <Box py={6} id="apply">
        <Container>
          <Grid container spacing={4}>
            <Grid item xs={12} md={6}>
              <Typography variant="h4" mb={3}>
                Apply Now
              </Typography>
              <Typography variant="body1" mb={2}>
                Ready to join our team? Fill out the application form and we'll get back to you soon.
              </Typography>
              <Typography variant="body1" mb={4}>
                For questions about the application process, email <Box component="span" sx={{ color: primaryBlue }}>hr@healinghandshospital.com</Box>
              </Typography>
              
              <Box mt={5}>
                <Typography variant="h6" mb={2}>
                  Not ready to apply?
                </Typography>
                <Typography variant="body1" mb={2}>
                  Join our talent network to stay updated on future opportunities:
                </Typography>
                <Box component="form" sx={{ mt: 3 }}>
                  <TextField
                    fullWidth
                    placeholder="Your email address"
                    variant="outlined"
                    sx={{ mb: 2 }}
                  />
                  <Button 
                    variant="outlined"
                    color="primary"
                    sx={{ color: primaryBlue, borderColor: primaryBlue }}
                  >
                    Subscribe
                  </Button>
                </Box>
              </Box>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Card sx={{ bgcolor: lightBlue, p: 3 }}>
                <Typography variant="h5" mb={3}>
                  Application Form
                </Typography>
                <Box component="form">
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Full Name"
                        variant="outlined"
                        required
                      />
                    </Grid>
                    
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Email"
                        type="email"
                        variant="outlined"
                        required
                      />
                    </Grid>
                    
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Phone"
                        type="tel"
                        variant="outlined"
                        required
                      />
                    </Grid>
                    
                    <Grid item xs={12}>
                      <FormControl fullWidth required>
                        <InputLabel>Position Applying For</InputLabel>
                        <Select
                          label="Position Applying For"
                          defaultValue=""
                        >
                          <MenuItem value="">Select a position</MenuItem>
                          <MenuItem value="nurse">Registered Nurse</MenuItem>
                          <MenuItem value="lab-tech">Medical Laboratory Technician</MenuItem>
                          <MenuItem value="pt">Physical Therapist</MenuItem>
                          <MenuItem value="it">IT Support Specialist</MenuItem>
                          <MenuItem value="other">Other</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        variant="outlined"
                        type="file"
                        required
                        label="Upload Resume"
                        InputLabelProps={{
                          shrink: true,
                        }}
                      />
                      <Typography variant="caption" color="text.secondary">
                        PDF, DOC, or DOCX files only
                      </Typography>
                    </Grid>
                    
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Cover Letter (Optional)"
                        variant="outlined"
                        multiline
                        rows={3}
                      />
                    </Grid>
                    
                    <Grid item xs={12}>
                      <Button 
                        variant="contained" 
                        color="primary" 
                        fullWidth
                        sx={{ bgcolor: primaryBlue, py: 1.5 }}
                      >
                        Submit Application
                      </Button>
                    </Grid>
                  </Grid>
                </Box>
              </Card>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </Box>
  );
}

export default CareersPage;